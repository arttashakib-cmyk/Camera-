# آزمایشگاه عیب‌یابی دوربین (Camera Diagnostic Lab)

اپلیکیشن Native اندروید (Kotlin + Jetpack Compose + Camera2) برای عیب‌یابی دوربین؛ فارسی، RTL، آفلاین، بدون حساب کاربری.

## ساخت APK فقط با گوشی (مرورگر موبایل)

1. در مرورگر گوشی وارد github.com شوید ← «New repository» ← یک نام (مثلاً `camera-lab`) ← **Create repository**.
2. فایل ZIP را در «Files» گوشی با لمس طولانی ← Extract/استخراج باز کنید (پوشه‌ی `CameraDiagnosticLab` ساخته می‌شود).
3. در صفحه‌ی مخزن: **Add file ← Upload files**. **همه‌ی محتویات داخل پوشه‌ی استخراج‌شده** را انتخاب کنید
   (`app`، `gradle`، `.github`، `build.gradle.kts`، `settings.gradle.kts`، `gradle.properties`، `gradlew`، `gradlew.bat`، `.gitignore`)
   و Commit کنید. اگر انتخاب پوشه‌ی مخفی `.github` در مرورگر ممکن نبود، مرحله‌ی ۴ را انجام دهید.
4. اطمینان از مسیر Workflow: در مخزن باید دقیقاً فایل `.github/workflows/android-apk.yml` دیده شود.
   اگر نیست: **Add file ← Create new file** ← در کادر نام بنویسید `.github/workflows/android-apk.yml`
   (با تایپ `/` پوشه ساخته می‌شود) ← محتوای فایل را از ZIP کپی کنید ← Commit.
5. اجرا: تب **Actions** ← در سمت راست/فهرست «Build Debug APK» ← **Run workflow** ← **Run workflow**.
   (با هر Commit روی شاخه‌ی main هم خودکار اجرا می‌شود.)
6. وضعیت: روی اجرای در حال انجام بزنید؛ ✓ سبز یعنی موفق، ✕ قرمز یعنی شکست. روی مرحله‌ی قرمز بزنید تا Log باز شود.
7. دانلود: در پایین صفحه‌ی اجرای موفق، بخش **Artifacts** ← `CameraDiagnosticLab-debug-APK` (یک ZIP) ← دانلود ← استخراج ← فایل `.apk`.
8. نصب روی Realme 11 Pro+: فایل APK را لمس کنید ← اگر خواست، «Install unknown apps/نصب از این منبع» را برای همان برنامه (Files/Chrome) مجاز کنید ← Install.
   (اگر Play Protect هشدار داد، چون APK امضای Debug دارد؛ «Install anyway».)
9. اجرا: برنامه را باز کنید ← «شروع آزمایش کامل» ← مجوز دوربین را بدهید. مجوز میکروفون فقط وقتی پرسیده می‌شود که در «تنظیمات» ضبط با صدا را روشن کرده باشید.
10. اگر Build شکست خورد: در Log، مرحله‌ی قرمز را باز کنید و **۳۰–۴۰ خط آخر** و اولین خط شامل `error:` یا `FAILED` را بفرستید.
    اگر مرحله‌ی «Run unit tests» قرمز شد، فایل‌های گزارش در Artifact با نام `test-and-build-reports` ذخیره می‌شود.

## یادداشت درباره‌ی Gradle Wrapper
فایل باینری `gradle-wrapper.jar` در ZIP نیست (امکان تولید باینری و دانلود در محیط ساخت نبود). Workflow اگر آن را نبیند،
خودش با `gradle wrapper --gradle-version 8.7` می‌سازد و سپس همه‌چیز با `./gradlew` اجرا می‌شود؛ نیازی به کار دستی نیست.

## محدودیت‌های مهم
- موفق‌بودن Camera2 در این برنامه، سلامت کامل برنامه‌ی دوربین کارخانه‌ای را ثابت نمی‌کند.
- نرم‌افزار نمی‌تواند فلت معیوب را از ماژول معیوب جدا کند؛ خروجی فقط «احتمال» است.
- برنامه به Logcat کامل سیستم دسترسی ندارد؛ برای خطاهای عمیق از Bug Report رسمی اندروید (در بخش راهنما) استفاده کنید. تحلیل Bug Report پیاده‌سازی نشده و دکمه‌ی نمایشی هم ندارد.
