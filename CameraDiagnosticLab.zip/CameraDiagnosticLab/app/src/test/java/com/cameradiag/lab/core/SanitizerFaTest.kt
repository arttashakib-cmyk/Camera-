package com.cameradiag.lab.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.util.TimeZone

class SanitizerFaTest {
    @Test
    fun redactsSensitiveValues() {
        val r = Sanitizer.redact("fail at /data/user/0/com.x/files/a.jpg for me@example.com ip 192.168.1.20 mac AA:BB:CC:DD:EE:FF id 123456789012")!!
        assertFalse(r.contains("/data/user"))
        assertFalse(r.contains("me@example.com"))
        assertFalse(r.contains("192.168.1.20"))
        assertFalse(r.contains("AA:BB:CC"))
        assertFalse(r.contains("123456789012"))
    }

    @Test
    fun nullAndShortTextPassThrough() {
        assertNull(Sanitizer.redact(null))
        assertEquals("camera error 5", Sanitizer.redact("camera error 5"))
    }

    @Test
    fun longTextIsTruncated() {
        assertTrue(Sanitizer.redact("x".repeat(2000))!!.length <= 601)
    }

    @Test
    fun persianDigits() {
        assertEquals("۱۲:۳۰ ۰۹", Fa.digits("12:30 09"))
    }

    @Test
    fun jalaliConversion() {
        assertEquals(Triple(1405, 7, 20), Fa.gregorianToJalali(2026, 10, 12))
        assertEquals(Triple(1405, 1, 1), Fa.gregorianToJalali(2026, 3, 21))
        assertEquals(Triple(1404, 1, 1), Fa.gregorianToJalali(2025, 3, 21))
    }

    @Test
    fun dateTimeFormat() {
        val ms = ZonedDateTime.of(2026, 10, 12, 12, 30, 0, 0, ZoneOffset.UTC).toInstant().toEpochMilli()
        assertEquals("۱۴۰۵/۰۷/۲۰ ۱۲:۳۰", Fa.dateTime(ms, TimeZone.getTimeZone("UTC")))
    }

    @Test
    fun userReportDefaults() {
        val u = UserReport()
        assertTrue(u.isEmpty())
        assertEquals(UserAnswer.UNKNOWN, u.answer(UserQuestions.STOCK_OPENS))
        assertFalse(u.reportsStockProblem())
        assertTrue(UserReport(mapOf(UserQuestions.STOCK_OPENS to UserAnswer.NO)).reportsStockProblem())
    }
}
