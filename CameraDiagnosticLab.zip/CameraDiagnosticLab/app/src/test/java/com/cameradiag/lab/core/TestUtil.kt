package com.cameradiag.lab.core

object T {
    fun cam(id: String, facing: LensFacing, flash: Boolean = false) = CameraInfo(
        id = id, lensFacing = facing, flashAvailable = flash, hardwareLevel = "LIMITED",
        capabilities = listOf("BACKWARD_COMPATIBLE"), sensorOrientation = 90, maxJpegSize = "4000x3000", physicalCameraIds = emptyList()
    )

    fun res(
        kind: TestKind, cam: String, status: TestStatus, cat: ErrorCategory? = null, stage: String? = null,
        message: String? = null, details: Map<String, String> = emptyMap()
    ) = TestResult(
        kind = kind, cameraId = cam, status = status, stage = stage, durationMs = 120, category = cat,
        exceptionType = if (status == TestStatus.FAILED) "com.example.Boom" else null,
        message = message, details = details, timestampMillis = 1_700_000_000_000L
    )

    fun allPassed(id: String) = listOf(
        res(TestKind.OPEN, id, TestStatus.PASSED),
        res(TestKind.PREVIEW, id, TestStatus.PASSED),
        res(TestKind.PHOTO, id, TestStatus.PASSED)
    )

    val back = cam("0", LensFacing.BACK, true)
    val front = cam("1", LensFacing.FRONT)

    fun input(
        cams: List<CameraInfo>, results: List<TestResult>, user: UserReport = UserReport(),
        perm: Boolean? = true, listError: String? = null
    ) = AnalysisInput(cams, results, user, perm, listError)

    val device = DeviceInfo("realme", "RMX3741", "15", 35, "2026-08-05", listOf("com.example.camera (1.2.3)"))

    fun report(results: List<TestResult>, cams: List<CameraInfo> = listOf(back, front), user: UserReport = UserReport()): DiagnosticReport {
        val a = RuleEngine.analyze(input(cams, results, user))
        return DiagnosticReport(device, 1_700_000_000_000L, RunMode.FULL, true, true, cams, null, results, user, a)
    }
}
