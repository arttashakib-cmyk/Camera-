package com.cameradiag.lab.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ErrorClassifierTest {
    @Test
    fun accessReasons() {
        assertEquals(ErrorCategory.DISABLED, ErrorClassifier.fromAccessReason(1))
        assertEquals(ErrorCategory.DISCONNECTED, ErrorClassifier.fromAccessReason(2))
        assertEquals(ErrorCategory.DEVICE_ERROR, ErrorClassifier.fromAccessReason(3))
        assertEquals(ErrorCategory.IN_USE, ErrorClassifier.fromAccessReason(4))
        assertEquals(ErrorCategory.IN_USE, ErrorClassifier.fromAccessReason(5))
        assertEquals(ErrorCategory.UNKNOWN, ErrorClassifier.fromAccessReason(99))
    }

    @Test
    fun deviceStateErrors() {
        assertEquals(ErrorCategory.IN_USE, ErrorClassifier.fromDeviceStateError(1))
        assertEquals(ErrorCategory.DISABLED, ErrorClassifier.fromDeviceStateError(3))
        assertEquals(ErrorCategory.DEVICE_ERROR, ErrorClassifier.fromDeviceStateError(4))
        assertEquals(ErrorCategory.SERVICE_ERROR, ErrorClassifier.fromDeviceStateError(5))
    }

    @Test
    fun throwables() {
        assertEquals(ErrorCategory.SESSION_CONFIG, ErrorClassifier.fromThrowable(CameraFailure(ErrorCategory.SESSION_CONFIG, "x")))
        assertEquals(ErrorCategory.SECURITY, ErrorClassifier.fromThrowable(SecurityException("no")))
        assertEquals(ErrorCategory.IO_FILE, ErrorClassifier.fromThrowable(java.io.IOException("disk")))
        assertEquals(ErrorCategory.CANCELLED, ErrorClassifier.fromThrowable(CancellationException("c")))
        assertEquals(ErrorCategory.UNKNOWN, ErrorClassifier.fromThrowable(IllegalStateException("?")))
    }

    @Test
    fun timeoutIsNotConfusedWithCancellation() = runBlocking {
        var caught: Throwable? = null
        try {
            withTimeout(20) { delay(2000) }
        } catch (e: TimeoutCancellationException) {
            caught = e
        }
        assertTrue(caught != null)
        assertEquals(ErrorCategory.TIMEOUT, ErrorClassifier.fromThrowable(caught!!))
    }

    @Test
    fun stackTopIsLimited() {
        val e = RuntimeException("x")
        assertTrue(ErrorClassifier.stackTop(e, 3).size <= 3)
    }
}
