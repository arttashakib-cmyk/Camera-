package com.cameradiag.lab.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleEngineTest {

    private fun causes(a: Analysis) = a.findings.map { it.cause }

    @Test
    fun noCameras_isNoData_notHealthy() {
        val a = RuleEngine.analyze(T.input(emptyList(), emptyList()))
        assertEquals(OverallStatus.NO_DATA, a.overall)
        assertTrue(Cause.CAMERA_SERVICE in causes(a))
        assertTrue(a.findings.none { it.confidence == Confidence.HIGH })
        assertEquals(RepairAdvice.CONSIDER, a.repairAdvice)
    }

    @Test
    fun noCameras_withListError_raisesConfidenceToMedium() {
        val a = RuleEngine.analyze(T.input(emptyList(), emptyList(), listError = "CameraAccessException (reason=3)"))
        val f = a.findings.first { it.cause == Cause.CAMERA_SERVICE }
        assertEquals(Confidence.MEDIUM, f.confidence)
    }

    @Test
    fun permissionDenied_isReportedAndNothingIsHealthy() {
        val results = listOf(TestKind.OPEN, TestKind.PREVIEW).map {
            T.res(it, "0", TestStatus.NOT_TESTED, ErrorCategory.PERMISSION, message = "مجوز داده نشد")
        }
        val a = RuleEngine.analyze(T.input(listOf(T.back), results, perm = false))
        assertEquals(OverallStatus.NO_DATA, a.overall)
        val f = a.findings.first { it.cause == Cause.ACCESS }
        assertEquals(Confidence.HIGH, f.confidence)
        assertEquals(RepairAdvice.UNDETERMINED, a.repairAdvice)
    }

    @Test
    fun onlyOpenPassed_isPartial_notPassed() {
        val a = RuleEngine.analyze(T.input(listOf(T.back), listOf(T.res(TestKind.OPEN, "0", TestStatus.PASSED))))
        assertEquals(OverallStatus.PARTIAL, a.overall)
        assertTrue(Cause.INCONCLUSIVE in causes(a))
    }

    @Test
    fun allCorePassed_neverClaimsDefiniteHealth() {
        val results = T.allPassed("0") + T.allPassed("1")
        val a = RuleEngine.analyze(T.input(listOf(T.back, T.front), results))
        assertEquals(OverallStatus.PASSED_TESTED_PATHS, a.overall)
        val inc = a.findings.first { it.cause == Cause.INCONCLUSIVE }
        assertEquals(Confidence.UNDETERMINED, inc.confidence)
        assertTrue(inc.evidenceFor.any { it.contains("سلامت کامل") })
        assertEquals(RepairAdvice.NOT_INDICATED_YET, a.repairAdvice)
        assertTrue(a.limitations.isNotEmpty())
    }

    @Test
    fun warningOrInconclusive_blocksPassedState() {
        val results = T.allPassed("0").map {
            if (it.kind == TestKind.PREVIEW) it.copy(status = TestStatus.WARNING, details = mapOf("black" to "true")) else it
        }
        val a = RuleEngine.analyze(T.input(listOf(T.back), results))
        assertNotEquals(OverallStatus.PASSED_TESTED_PATHS, a.overall)
    }

    @Test
    fun sessionCreationFailure_isDetected() {
        val results = listOf(
            T.res(TestKind.OPEN, "0", TestStatus.PASSED),
            T.res(TestKind.PREVIEW, "0", TestStatus.FAILED, ErrorCategory.SESSION_CONFIG, stage = "createSession")
        )
        val a = RuleEngine.analyze(T.input(listOf(T.back), results))
        assertEquals(OverallStatus.ISSUES_FOUND, a.overall)
        val f = a.findings.first { it.cause == Cause.SESSION_CREATION }
        assertEquals(Confidence.MEDIUM, f.confidence)
        assertTrue(f.evidenceAgainst.isNotEmpty())
    }

    @Test
    fun noFramesOnRearWhileFrontWorks_pointsToModule_butNeverHigh() {
        val results = listOf(
            T.res(TestKind.OPEN, "0", TestStatus.PASSED),
            T.res(TestKind.PREVIEW, "0", TestStatus.FAILED, ErrorCategory.NO_FRAMES, stage = "waitFrames")
        ) + T.allPassed("1")
        val a = RuleEngine.analyze(T.input(listOf(T.back, T.front), results, UserReport(mapOf(UserQuestions.AFTER_REPAIR to UserAnswer.YES))))
        val f = a.findings.first { it.cause == Cause.CAMERA_MODULE }
        assertEquals(Confidence.MEDIUM, f.confidence)
        assertTrue(f.evidenceFor.any { it.contains("[گزارش کاربر]") })
        assertTrue(a.findings.none { it.confidence == Confidence.HIGH && (it.cause == Cause.CAMERA_MODULE || it.cause == Cause.CONNECTION_FLEX) })
        assertEquals(RepairAdvice.RECOMMENDED, a.repairAdvice)
    }

    @Test
    fun openTimeoutOnRear_pointsToConnection() {
        val results = listOf(T.res(TestKind.OPEN, "0", TestStatus.FAILED, ErrorCategory.TIMEOUT, stage = "openCamera")) + T.allPassed("1")
        val a = RuleEngine.analyze(T.input(listOf(T.back, T.front), results))
        assertTrue(Cause.CONNECTION_FLEX in causes(a))
    }

    @Test
    fun camera2Works_butStockAppBroken_reportsSoftwareWithCaveat() {
        val user = UserReport(
            mapOf(
                UserQuestions.CRASH_ON_SWITCH to UserAnswer.YES,
                UserQuestions.AFTER_REPAIR to UserAnswer.YES
            )
        )
        val a = RuleEngine.analyze(T.input(listOf(T.back), T.allPassed("0"), user))
        val f = a.findings.first { it.cause == Cause.APP_SOFTWARE }
        assertEquals(Confidence.MEDIUM, f.confidence)
        assertTrue(f.evidenceAgainst.any { it.contains("بعد از تعمیر") })
        assertTrue(f.evidenceAgainst.any { it.contains("Camera2") })
    }

    @Test
    fun photoFailsAfterPreviewPasses_pointsToImagePipeline() {
        val results = listOf(
            T.res(TestKind.OPEN, "0", TestStatus.PASSED),
            T.res(TestKind.PREVIEW, "0", TestStatus.PASSED),
            T.res(TestKind.PHOTO, "0", TestStatus.FAILED, ErrorCategory.TIMEOUT, stage = "waitImage")
        )
        val a = RuleEngine.analyze(T.input(listOf(T.back), results))
        assertTrue(Cause.IMAGE_PIPELINE in causes(a))
    }

    @Test
    fun rapidSwitchFailure_pointsToCameraService() {
        val results = T.allPassed("0") + T.allPassed("1") +
            T.res(TestKind.SWITCH, "0↔1", TestStatus.FAILED, ErrorCategory.TIMEOUT, stage = "cycle2/camera0:openCamera")
        val a = RuleEngine.analyze(T.input(listOf(T.back, T.front), results))
        assertTrue(Cause.CAMERA_SERVICE in causes(a))
    }

    @Test
    fun cameraInUse_isAccessIssue_notHardware() {
        val results = listOf(T.res(TestKind.OPEN, "0", TestStatus.FAILED, ErrorCategory.IN_USE, stage = "openCamera"))
        val a = RuleEngine.analyze(T.input(listOf(T.back), results))
        assertTrue(Cause.ACCESS in causes(a))
        assertFalse(Cause.CAMERA_MODULE in causes(a))
    }

    @Test
    fun unsupported_isNotCountedAsFailure() {
        val results = T.allPassed("0") + T.res(TestKind.FLASH, "0", TestStatus.UNSUPPORTED, ErrorCategory.UNSUPPORTED)
        val a = RuleEngine.analyze(T.input(listOf(T.back), results))
        assertNotEquals(OverallStatus.ISSUES_FOUND, a.overall)
    }

    @Test
    fun userAnswersAlone_neverProduceHardwareFinding() {
        val user = UserReport(mapOf(UserQuestions.REAR_BLACK to UserAnswer.YES, UserQuestions.AFTER_REPAIR to UserAnswer.YES))
        val a = RuleEngine.analyze(T.input(listOf(T.back), emptyList(), user))
        assertFalse(Cause.CAMERA_MODULE in causes(a))
        assertFalse(Cause.CONNECTION_FLEX in causes(a))
    }
}
