package com.cameradiag.lab.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GuardTest {
    @Test
    fun success_isReported() = runBlocking {
        val r = Guard.run(TestKind.OPEN, "0", 2000) { t ->
            t.set("openCamera")
            TestOutcome(TestStatus.PASSED, "ok", mapOf("openMs" to "5"))
        }
        assertEquals(TestStatus.PASSED, r.status)
        assertEquals("5", r.details["openMs"])
    }

    @Test
    fun timeout_failsWithStuckStage() = runBlocking {
        val r = Guard.run(TestKind.PREVIEW, "0", 150) { t ->
            t.set("createSession")
            delay(10_000)
            TestOutcome(TestStatus.PASSED)
        }
        assertEquals(TestStatus.FAILED, r.status)
        assertEquals(ErrorCategory.TIMEOUT, r.category)
        assertEquals("createSession", r.stage)
        assertTrue(r.message!!.contains("createSession"))
    }

    @Test
    fun hungBlockingCall_doesNotFreezeCaller() = runBlocking {
        val started = System.currentTimeMillis()
        val r = Guard.run(TestKind.VIDEO, "0", 150) { t ->
            t.set("recorderStop")
            Thread.sleep(3000) // a blocking call that cannot be cancelled
            TestOutcome(TestStatus.PASSED)
        }
        val took = System.currentTimeMillis() - started
        assertEquals(ErrorCategory.TIMEOUT, r.category)
        assertTrue("caller must return quickly but took $took ms", took < 2000)
    }

    @Test
    fun cameraFailure_isClassified() = runBlocking {
        val r = Guard.run(TestKind.PREVIEW, "0", 2000) { t ->
            t.set("createSession")
            throw CameraFailure(ErrorCategory.SESSION_CONFIG, "onConfigureFailed", "createSession")
        }
        assertEquals(TestStatus.FAILED, r.status)
        assertEquals(ErrorCategory.SESSION_CONFIG, r.category)
        assertEquals("createSession", r.stage)
        assertEquals("com.cameradiag.lab.core.CameraFailure", r.exceptionType)
        assertTrue(r.stackTop.isNotEmpty())
    }

    @Test
    fun unexpectedException_isFailedUnknown() = runBlocking {
        val r = Guard.run(TestKind.PHOTO, "1", 2000) { _ -> throw IllegalStateException("boom /data/user/0/x/files/a.jpg") }
        assertEquals(TestStatus.FAILED, r.status)
        assertEquals(ErrorCategory.UNKNOWN, r.category)
        assertTrue(!r.message!!.contains("/data/user"))
    }

    @Test
    fun cancellation_recordsNotTested_andRethrows() = runBlocking {
        var captured: TestResult? = null
        var rethrown = false
        val job = launch {
            try {
                Guard.run(TestKind.OPEN, "0", 10_000, onCancelled = { captured = it }) { t ->
                    t.set("openCamera")
                    delay(10_000)
                    TestOutcome(TestStatus.PASSED)
                }
            } catch (e: CancellationException) {
                rethrown = true
                throw e
            }
        }
        delay(150)
        job.cancelAndJoin()
        assertNotNull(captured)
        assertEquals(TestStatus.NOT_TESTED, captured!!.status)
        assertEquals(ErrorCategory.CANCELLED, captured!!.category)
        assertTrue(rethrown)
    }
}
