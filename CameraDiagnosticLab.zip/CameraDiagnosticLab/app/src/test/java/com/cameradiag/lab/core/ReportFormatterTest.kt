package com.cameradiag.lab.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportFormatterTest {

    private val H_OK = "آزمایش انجام شد و موفق بود"
    private val H_FAIL = "آزمایش انجام شد و شکست خورد"
    private val H_UNSURE = "آزمایش انجام نشد یا نتیجه قطعی نیست"

    private fun sampleResults() = listOf(
        T.res(TestKind.OPEN, "0", TestStatus.PASSED),
        T.res(TestKind.PREVIEW, "0", TestStatus.FAILED, ErrorCategory.NO_FRAMES, "waitFrames", "هیچ فریمی نرسید /data/user/0/com.x/files/a.jpg"),
        T.res(TestKind.VIDEO, "0", TestStatus.NOT_TESTED, ErrorCategory.CANCELLED, message = "لغو شد"),
        T.res(TestKind.FLASH, "0", TestStatus.INCONCLUSIVE, message = "تأیید کاربر نیامد")
    )

    @Test
    fun threeGroupsAreDistinct() {
        val text = ReportFormatter.toText(T.report(sampleResults()))
        val iOk = text.indexOf(H_OK)
        val iFail = text.indexOf(H_FAIL)
        val iUnsure = text.indexOf(H_UNSURE)
        assertTrue(iOk in 0 until iFail && iFail < iUnsure)
        val ok = text.substring(iOk, iFail)
        val fail = text.substring(iFail, iUnsure)
        val unsure = text.substring(iUnsure, text.indexOf("خطاهای ثبت"))
        assertTrue(ok.contains("بازشدن دوربین"))
        assertFalse(ok.contains("پیش‌نمایش"))
        assertTrue(fail.contains("پیش‌نمایش"))
        assertTrue(unsure.contains("فیلم‌برداری"))
        assertTrue(unsure.contains("چراغ‌قوه"))
        assertFalse(ok.contains("فیلم‌برداری"))
        assertFalse(fail.contains("فیلم‌برداری"))
    }

    @Test
    fun textNeverClaimsDefiniteHealth_evenWhenEverythingPassed() {
        val results = T.allPassed("0") + T.allPassed("1")
        val text = ReportFormatter.toText(T.report(results))
        assertTrue(text.contains("هرگز «سلامت قطعی»"))
        assertFalse(text.contains("دوربین سالم است"))
        assertTrue(text.contains("سلامت کامل"))
        assertTrue(text.contains("محدودیت‌های تشخیص"))
    }

    @Test
    fun noDataReport_listsNothingAsPassed() {
        val rep = T.report(emptyList(), emptyList())
        val text = ReportFormatter.toText(rep)
        val ok = text.substring(text.indexOf(H_OK), text.indexOf(H_FAIL))
        assertTrue(ok.contains("(موردی نیست)"))
        assertEquals(OverallStatus.NO_DATA, rep.analysis.overall)
    }

    @Test
    fun pathsAreRedactedInTextAndJson() {
        val rep = T.report(sampleResults())
        val text = ReportFormatter.toText(rep)
        val json = ReportFormatter.toJson(rep)
        assertFalse(text.contains("/data/user"))
        assertFalse(json.contains("/data/user"))
    }

    @Test
    fun jsonIsValidAndHasKeyFields() {
        val user = UserReport(mapOf(UserQuestions.AFTER_REPAIR to UserAnswer.YES))
        val json = ReportFormatter.toJson(T.report(sampleResults(), user = user))
        val root = MiniJson.parse(json) as Map<*, *>
        assertEquals("Camera Diagnostic Lab", root["app"])
        assertTrue(root["results"] is List<*>)
        assertEquals(4, (root["results"] as List<*>).size)
        val dev = root["device"] as Map<*, *>
        assertEquals("RMX3741", dev["model"])
        val analysis = root["analysis"] as Map<*, *>
        assertEquals("ISSUES_FOUND", analysis["overall"])
        val first = (root["results"] as List<*>)[0] as Map<*, *>
        assertEquals("PASSED", first["status"])
        assertEquals("15", first["androidVersion"])
    }

    @Test
    fun jsonEscapesSpecialCharacters() {
        val s = Json.stringify(mapOf("a" to "he said \"hi\"\n\\ ✓ فارسی \u0001"))
        val m = MiniJson.parse(s) as Map<*, *>
        assertEquals("he said \"hi\"\n\\ ✓ فارسی \u0001", m["a"])
    }

    @Test
    fun userReportIsMarkedAsNotMeasured() {
        val user = UserReport(mapOf(UserQuestions.REAR_BLACK to UserAnswer.YES))
        val text = ReportFormatter.toText(T.report(sampleResults(), user = user))
        assertTrue(text.contains("اندازه‌گیری مستقیم نیست"))
    }
}

/** Minimal strict JSON parser used only to prove the generated JSON is well-formed. */
object MiniJson {
    fun parse(s: String): Any? {
        val p = Parser(s)
        p.ws()
        val v = p.value()
        p.ws()
        if (p.i != s.length) throw IllegalArgumentException("trailing data at ${p.i}")
        return v
    }

    private class Parser(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            ws()
            if (i >= s.length) throw IllegalArgumentException("eof")
            return when (val c = s[i]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalArgumentException("bad char $c at $i")
            }
        }
        fun lit(w: String, v: Any?): Any? {
            if (!s.startsWith(w, i)) throw IllegalArgumentException("bad literal at $i")
            i += w.length
            return v
        }
        fun num(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            return s.substring(st, i).toDouble()
        }
        fun str(): String {
            i++
            val sb = StringBuilder()
            while (true) {
                if (i >= s.length) throw IllegalArgumentException("unterminated string")
                val c = s[i++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        when (val e = s[i++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'b' -> sb.append('\b')
                            'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> throw IllegalArgumentException("bad escape $e")
                        }
                    }
                    c < ' ' -> throw IllegalArgumentException("raw control char in string")
                    else -> sb.append(c)
                }
            }
        }
        fun arr(): List<Any?> {
            i++
            val out = ArrayList<Any?>()
            ws()
            if (s[i] == ']') { i++; return out }
            while (true) {
                out.add(value())
                ws()
                val c = s[i++]
                if (c == ']') return out
                if (c != ',') throw IllegalArgumentException("expected , in array")
            }
        }
        fun obj(): Map<String, Any?> {
            i++
            val out = LinkedHashMap<String, Any?>()
            ws()
            if (s[i] == '}') { i++; return out }
            while (true) {
                ws()
                if (s[i] != '"') throw IllegalArgumentException("expected key at $i")
                val k = str()
                ws()
                if (s[i++] != ':') throw IllegalArgumentException("expected :")
                out[k] = value()
                ws()
                val c = s[i++]
                if (c == '}') return out
                if (c != ',') throw IllegalArgumentException("expected , in object")
            }
        }
    }
}
