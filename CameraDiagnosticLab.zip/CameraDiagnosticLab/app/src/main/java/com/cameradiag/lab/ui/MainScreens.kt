package com.cameradiag.lab.ui

import android.graphics.SurfaceTexture
import android.view.TextureView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.cameradiag.lab.MainViewModel
import com.cameradiag.lab.Screen
import com.cameradiag.lab.UiState
import com.cameradiag.lab.core.CameraInfo
import com.cameradiag.lab.core.Fa
import com.cameradiag.lab.core.Labels
import com.cameradiag.lab.core.OverallStatus
import com.cameradiag.lab.core.RunMode

private fun overallColor(o: OverallStatus): Color = when (o) {
    OverallStatus.NO_DATA -> StatusColors.neutral
    OverallStatus.ISSUES_FOUND -> StatusColors.failed
    OverallStatus.PARTIAL -> StatusColors.warning
    OverallStatus.PASSED_TESTED_PATHS -> StatusColors.info // never green: no definitive health claim
}

private fun cameraSummary(c: CameraInfo): String =
    "دوربین ${Fa.digits(c.id)} — ${Labels.facing(c.lensFacing)} | فلش: ${if (c.flashAvailable) "دارد" else "ندارد"} | سطح: ${c.hardwareLevel}"

@Composable
fun HomeScreen(vm: MainViewModel, s: UiState) {
    val lastOverall: OverallStatus? = s.lastReport?.analysis?.overall
        ?: s.history.firstOrNull()?.let { e -> OverallStatus.values().firstOrNull { it.name == e.overall } }
    val lastTime: Long? = s.lastReport?.timestampMillis ?: s.history.firstOrNull()?.timestampMillis
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("آزمایشگاه عیب‌یابی دوربین", style = MaterialTheme.typography.headlineSmall)
            Muted("آزمایش واقعی با Camera2 · کاملاً آفلاین · بدون ارسال داده")
        }
        item {
            AppCard {
                SectionTitle("دستگاه")
                Body("${s.device.manufacturer} ${s.device.model}")
                Body("اندروید ${Fa.digits(s.device.androidRelease)} (API ${Fa.digits(s.device.sdkInt.toString())})")
                Body("تعداد دوربین‌های شناسایی‌شده: ${Fa.digits(s.cameras.size.toString())}")
                if (s.cameraListError != null) Muted("خطا در فهرست‌کردن دوربین‌ها: ${s.cameraListError}")
            }
        }
        item {
            AppCard {
                SectionTitle("وضعیت کلی تشخیص")
                if (lastOverall == null) {
                    Body("هنوز آزمایشی انجام نشده است. وضعیت «نامشخص» است، نه «سالم».")
                } else {
                    Chip(Labels.overall(lastOverall), overallColor(lastOverall))
                    if (lastTime != null) Muted("آخرین آزمایش: ${Fa.dateTime(lastTime)}")
                }
                Muted("برنامه هیچ‌گاه بدون شواهد کافی «سلامت قطعی» اعلام نمی‌کند.")
            }
        }
        item { PrimaryButton("شروع آزمایش کامل") { vm.startRun(RunMode.FULL) } }
        item { SecondaryButton("آزمایش سریع (بازشدن + پیش‌نمایش)") { vm.startRun(RunMode.QUICK) } }
        item { SecondaryButton("گزارش دستی خرابی") { vm.navigate(Screen.USER_REPORT) } }
        item { SectionTitle("بخش‌ها") }
        item { SecondaryButton("شناسایی دستگاه و دوربین‌ها") { vm.navigate(Screen.DEVICES) } }
        item { SecondaryButton("تست دستی دوربین") { vm.navigate(Screen.MANUAL) } }
        item { SecondaryButton("نتایج و تحلیل") { vm.navigate(Screen.RESULTS) } }
        item { SecondaryButton("گزارش‌ها و تاریخچه") { vm.navigate(Screen.HISTORY) } }
        item { SecondaryButton("راهنمای رفع مشکل") { vm.navigate(Screen.GUIDE) } }
        item { SecondaryButton("تنظیمات و حریم خصوصی") { vm.navigate(Screen.SETTINGS) } }
    }
}

@Composable
fun DevicesScreen(vm: MainViewModel, s: UiState) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("شناسایی دستگاه و دوربین‌ها") { vm.back() }
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AppCard {
                    SectionTitle("دستگاه")
                    Body("سازنده/مدل: ${s.device.manufacturer} ${s.device.model}")
                    Body("اندروید: ${Fa.digits(s.device.androidRelease)} (API ${Fa.digits(s.device.sdkInt.toString())})")
                    s.device.securityPatch?.let { Body("وصله‌ی امنیتی: ${Fa.digits(it)}") }
                    if (s.device.stockCameraApps.isEmpty()) Muted("برنامه‌ی دوربین اصلی شناسایی نشد.")
                    else s.device.stockCameraApps.forEach { Muted("برنامه‌ی دوربین: $it") }
                    Body("مجوز دوربین: " + if (s.cameraPermission) "داده شده" else "داده نشده (هنگام آزمایش درخواست می‌شود)")
                }
            }
            if (s.cameras.isEmpty()) {
                item {
                    AppCard {
                        SectionTitle("هیچ دوربینی گزارش نشد")
                        Body("Camera2 فهرستی خالی برگرداند. این می‌تواند نشانه‌ی مشکل سرویس دوربین یا محدودیت دسترسی باشد؛ به‌تنهایی قطعی نیست.")
                        if (s.cameraListError != null) Muted(s.cameraListError)
                    }
                }
            }
            items(s.cameras) { c ->
                AppCard {
                    SectionTitle("دوربین ${Fa.digits(c.id)} — ${Labels.facing(c.lensFacing)}")
                    Body("فلش: ${if (c.flashAvailable) "دارد" else "ندارد"} · سطح سخت‌افزار: ${c.hardwareLevel}")
                    Body("جهت حسگر: ${c.sensorOrientation?.let { Fa.digits(it.toString()) } ?: "نامشخص"} · بزرگ‌ترین JPEG: ${c.maxJpegSize?.let { Fa.digits(it) } ?: "نامشخص"}")
                    if (c.capabilities.isNotEmpty()) Muted("قابلیت‌ها: ${c.capabilities.joinToString("، ")}")
                    if (c.physicalCameraIds.isNotEmpty()) Muted("دوربین‌های فیزیکی زیرمجموعه: ${c.physicalCameraIds.joinToString("، ")}")
                    if (c.note != null) Muted(c.note)
                }
            }
            item {
                Muted("توجه: شناسه‌ی دوربین به‌تنهایی تضمین نمی‌کند که دوربین اصلی یا سلفی باشد؛ جهت از مشخصات واقعی خوانده شده است.")
            }
            item { SecondaryButton("به‌روزرسانی فهرست") { vm.refreshAll() } }
        }
    }
}

@Composable
fun AutoScreen(vm: MainViewModel, s: UiState) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("اجرای تست خودکار") { vm.back() }
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!s.running) {
                item {
                    AppCard {
                        SectionTitle("پیش از شروع")
                        Body("آزمایش کامل: بازشدن، پیش‌نمایش، عکس، فیلم کوتاه، چراغ‌قوه و جابه‌جایی سریع بین دوربین‌ها. ممکن است چراغ‌قوه چند ثانیه روشن شود و از شما تأیید بخواهد. عکس و فیلم آزمایشی فقط در حافظه‌ی خصوصی برنامه ذخیره می‌شود.")
                    }
                }
                item { PrimaryButton("شروع آزمایش کامل") { vm.startRun(RunMode.FULL) } }
                item { SecondaryButton("آزمایش سریع") { vm.startRun(RunMode.QUICK) } }
            } else {
                item {
                    AppCard {
                        SectionTitle("در حال آزمایش…")
                        LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                        s.currentStep?.let { Body(it) }
                        Muted("با خروج از برنامه، آزمایش لغو و منابع دوربین آزاد می‌شود.")
                    }
                }
                item { SecondaryButton("لغو آزمایش") { vm.cancelRun() } }
            }
            if (!s.running && s.lastReport != null && s.steps.isNotEmpty()) {
                item {
                    AppCard {
                        SectionTitle("آزمایش پایان یافت" + if (s.lastReport.completed) "" else " (لغو شد)")
                        Chip(Labels.overall(s.lastReport.analysis.overall), overallColor(s.lastReport.analysis.overall))
                    }
                }
                item { PrimaryButton("مشاهده‌ی نتایج و تحلیل") { vm.navigate(Screen.RESULTS) } }
            }
            val facing = s.cameras.associate { it.id to it.lensFacing }
            items(s.steps.reversed()) { r -> ResultRow(r, facing[r.cameraId]) }
        }
    }
}

@Composable
fun ManualScreen(vm: MainViewModel, s: UiState) {
    var selected by remember { mutableStateOf<String?>(null) }
    var texture by remember { mutableStateOf<SurfaceTexture?>(null) }

    DisposableEffect(Unit) { onDispose { vm.stopManual() } }
    LaunchedEffect(selected, texture) {
        val id = selected
        val st = texture
        if (id != null && st != null) vm.startPreview(id, st)
    }

    val selInfo = s.cameras.firstOrNull { it.id == selected }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("تست دستی دوربین") { vm.back() }
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AppCard {
                    SectionTitle("انتخاب دوربین")
                    if (!s.cameraPermission) Muted("برای پیش‌نمایش، مجوز دوربین لازم است. با «شروع آزمایش کامل» مجوز درخواست می‌شود یا آن را در تنظیمات گوشی بدهید.")
                    if (s.cameras.isEmpty()) Body("دوربینی شناسایی نشد.")
                    s.cameras.forEach { c ->
                        SecondaryButton(Labels.camera(Fa.digits(c.id), c.lensFacing) + if (c.id == selected) "  ● فعال" else "", enabled = s.cameraPermission) {
                            selected = c.id
                        }
                    }
                    Muted("عوض‌کردن سریع دوربین‌ها در این صفحه، همان سناریوی خطای برنامه‌ی دوربین اصلی را آزمایش می‌کند؛ خطاها ثبت می‌شوند.")
                }
            }
            val id = selected
            if (id != null) {
                item {
                    val ratio = remember(id) { vm.previewAspect(id) }
                    AndroidView(
                        factory = { c ->
                            TextureView(c).apply {
                                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { texture = st }
                                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                                        texture = null
                                        vm.preview.stop()
                                        return true
                                    }
                                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().aspectRatio(ratio)
                    )
                }
                item {
                    AppCard {
                        s.previewStatus?.let { Body(it) }
                        s.previewError?.let { Text(it, color = StatusColors.failed) }
                        if (s.previewRunning) {
                            Body("آیا تصویر پیش‌نمایش درست دیده می‌شود؟")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PrimaryButton("بله، درست است", Modifier.weight(1f)) { vm.answerPreviewVisual(id, true) }
                                SecondaryButton("سیاه/خراب است", Modifier.weight(1f)) { vm.answerPreviewVisual(id, false) }
                            }
                        }
                    }
                }
                if (selInfo?.flashAvailable == true) {
                    item {
                        AppCard {
                            SectionTitle("چراغ‌قوه")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PrimaryButton("روشن", Modifier.weight(1f)) { vm.setTorch(id, true) }
                                SecondaryButton("خاموش", Modifier.weight(1f)) { vm.setTorch(id, false) }
                            }
                            if (s.torchOn) {
                                Body("چراغ‌قوه روشن شد؟")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PrimaryButton("بله", Modifier.weight(1f)) { vm.answerTorchVisual(id, true) }
                                    SecondaryButton("نه", Modifier.weight(1f)) { vm.answerTorchVisual(id, false) }
                                }
                            }
                            Muted("موفق‌بودن دستور نرم‌افزاری به‌تنهایی سلامت سخت‌افزار را ثابت نمی‌کند؛ نتیجه‌ی عملی را شما تأیید می‌کنید.")
                        }
                    }
                }
            }
            item { SecondaryButton("گزارش دستی خرابی (برنامه‌ی دوربین اصلی)") { vm.navigate(Screen.USER_REPORT) } }
        }
    }
}

@Composable
fun ResultsScreen(vm: MainViewModel, s: UiState) {
    val r = s.lastReport
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("نتایج و تحلیل") { vm.back() }
        LazyColumn(
            Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (r == null) {
                item {
                    AppCard {
                        SectionTitle("هنوز نتیجه‌ای نیست")
                        Body("ابتدا یک آزمایش اجرا کنید. تا آن زمان همه‌ی موارد «انجام نشد» محسوب می‌شوند، نه «سالم».")
                        if (s.history.isNotEmpty()) Muted("گزارش‌های قبلی را در بخش «گزارش‌ها و تاریخچه» ببینید.")
                    }
                }
                item { PrimaryButton("شروع آزمایش کامل") { vm.startRun(RunMode.FULL) } }
            } else {
                val a = r.analysis
                val facing = r.cameras.associate { it.id to it.lensFacing }
                item {
                    AppCard {
                        SectionTitle("وضعیت کلی")
                        Chip(Labels.overall(a.overall), overallColor(a.overall))
                        Muted("${Labels.mode(r.mode)} · ${Fa.dateTime(r.timestampMillis)}" + if (r.completed) "" else " · ناتمام")
                    }
                }
                item {
                    AppCard {
                        SectionTitle("تعمیرکار")
                        Body(Labels.repair(a.repairAdvice))
                        Muted(a.repairNote)
                    }
                }
                item { SectionTitle("علت‌های احتمالی") }
                items(a.findings) { f ->
                    AppCard {
                        Text(Labels.cause(f.cause), style = MaterialTheme.typography.titleSmall)
                        Chip(Labels.confidence(f.confidence), if (f.confidence.ordinal >= 2) StatusColors.warning else StatusColors.neutral)
                        f.evidenceFor.forEach { Body("＋ $it") }
                        f.evidenceAgainst.forEach { Muted("－ $it") }
                        Body("گام بعدی: ${f.nextStep}")
                    }
                }
                item { SectionTitle("نتیجه‌ی هر آزمایش") }
                items(r.results) { res -> ResultRow(res, facing[res.cameraId]) }
                item {
                    AppCard {
                        SectionTitle("محدودیت‌های تشخیص")
                        a.limitations.forEach { Muted("• $it") }
                    }
                }
                item { SecondaryButton("تحلیل دوباره با گزارش کاربر و آزمایش‌های دستی") { vm.reanalyze() } }
                item { SecondaryButton("اشتراک‌گذاری گزارش") { vm.requestShare(s.lastEntry) } }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}
