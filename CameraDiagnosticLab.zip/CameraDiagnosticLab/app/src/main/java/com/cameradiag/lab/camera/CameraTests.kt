package com.cameradiag.lab.camera

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.ImageReader
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import android.util.Size
import com.cameradiag.lab.core.CameraFailure
import com.cameradiag.lab.core.CameraInfo
import com.cameradiag.lab.core.ErrorCategory
import com.cameradiag.lab.core.ErrorClassifier
import com.cameradiag.lab.core.StageTracker
import com.cameradiag.lab.core.TestOutcome
import com.cameradiag.lab.core.TestStatus
import com.cameradiag.lab.core.UserAnswer
import com.cameradiag.lab.data.SampleStore
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.sqrt

/**
 * Real Camera2 tests. Every function either returns a TestOutcome describing what happened, or throws
 * (CameraFailure / other exception) which Guard converts to a FAILED result. Nothing here fakes a result.
 * All hardware resources are released in `finally` through Closer, also on timeout or cancellation.
 */
class CameraTests(private val context: Context, private val samples: SampleStore) {
    private val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun chars(id: String, t: StageTracker): CameraCharacteristics {
        t.set("getCharacteristics")
        try {
            return mgr.getCameraCharacteristics(id)
        } catch (e: CameraAccessException) {
            throw mapAccess(e, "getCharacteristics")
        } catch (e: IllegalArgumentException) {
            throw CameraFailure(ErrorCategory.UNSUPPORTED, "شناسه‌ی دوربین معتبر نیست: ${e.message}", "getCharacteristics", e)
        }
    }

    private fun elapsed(since: Long): Long = SystemClock.elapsedRealtime() - since

    // ------------------------------------------------------------------ OPEN
    suspend fun open(id: String, thread: CameraThread, t: StageTracker): TestOutcome {
        val closer = Closer()
        try {
            t.set("openCamera")
            val t0 = SystemClock.elapsedRealtime()
            openManaged(mgr, id, thread, closer)
            val ms = elapsed(t0)
            val details = mapOf("openMs" to ms.toString())
            return if (ms > 4000) TestOutcome(TestStatus.WARNING, "دوربین باز شد اما بازشدن کند بود (${ms}ms).", details)
            else TestOutcome(TestStatus.PASSED, "دوربین در ${ms}ms باز شد.", details)
        } finally {
            closer.closeAll()
        }
    }

    // ------------------------------------------------------------------ PROBE (frames via YUV ImageReader)
    data class Probe(
        val openMs: Long, val sessionMs: Long, val firstFrameMs: Long,
        val frames: Int, val lumaMean: Double, val lumaStd: Double, val captureFailures: Int
    )

    suspend fun probe(
        id: String, thread: CameraThread, t: StageTracker,
        targetFrames: Int, waitMs: Long, prefix: String = ""
    ): Probe {
        val closer = Closer()
        try {
            val ch = chars(id, t)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val size = pickClosest(map?.getOutputSizes(ImageFormat.YUV_420_888), 640, 480, 1280L * 720)
                ?: throw CameraFailure(ErrorCategory.UNSUPPORTED, "اندازه‌ی خروجی YUV برای این دوربین گزارش نشد.", "getCharacteristics")

            t.set(prefix + "openCamera")
            val t0 = SystemClock.elapsedRealtime()
            val cam = openManaged(mgr, id, thread, closer)
            val openMs = elapsed(t0)

            val stats = FrameStats()
            val first = cam.newWaiter<Unit>()
            val enough = cam.newWaiter<Unit>()
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.YUV_420_888, 3)
            closer.add { reader.close() }
            closer.add { reader.setOnImageAvailableListener(null, null) }
            val tStart = SystemClock.elapsedRealtime()
            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    try {
                        val n = stats.frames.incrementAndGet()
                        if (n == 1) {
                            stats.firstFrameAt = SystemClock.elapsedRealtime()
                            first.complete(Unit)
                        }
                        if (n >= 3) computeLuma(img, stats)
                        if (n >= targetFrames) enough.complete(Unit)
                    } finally {
                        img.close()
                    }
                }
            }, thread.handler)

            t.set(prefix + "createSession")
            val t1 = SystemClock.elapsedRealtime()
            val session = createSession(cam, listOf(reader.surface), thread, closer)
            val sessionMs = elapsed(t1)
            closer.add { session.stopRepeating() }

            t.set(prefix + "setRepeatingRequest")
            val req = try {
                val b = cam.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                b.addTarget(reader.surface)
                applyAuto(b, ch)
                b.build()
            } catch (e: CameraAccessException) {
                throw mapAccess(e, "setRepeatingRequest")
            }
            val cb = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                    stats.captureFailures.incrementAndGet()
                }
            }
            try {
                session.setRepeatingRequest(req, cb, thread.handler)
            } catch (e: CameraAccessException) {
                throw mapAccess(e, "setRepeatingRequest")
            } catch (e: IllegalStateException) {
                throw CameraFailure(ErrorCategory.DISCONNECTED, "IllegalStateException: ${e.message}", "setRepeatingRequest", e)
            }

            t.set(prefix + "waitFrames")
            withTimeoutOrNull(waitMs) { enough.await() }
            val n = stats.frames.get()
            if (n == 0) {
                throw CameraFailure(
                    ErrorCategory.NO_FRAMES,
                    "دوربین باز شد و Session ساخته شد، اما در ${waitMs}ms هیچ فریمی دریافت نشد (خطای ثبت فریم: ${stats.captureFailures.get()}).",
                    prefix + "waitFrames"
                )
            }
            val firstMs = if (stats.firstFrameAt > 0) stats.firstFrameAt - tStart else -1L
            return Probe(openMs, sessionMs, firstMs, n, stats.lumaMean, stats.lumaStd, stats.captureFailures.get())
        } finally {
            closer.closeAll()
        }
    }

    // ------------------------------------------------------------------ PREVIEW
    suspend fun preview(id: String, thread: CameraThread, t: StageTracker): TestOutcome {
        val p = probe(id, thread, t, targetFrames = 12, waitMs = 6000)
        val details = linkedMapOf(
            "openMs" to p.openMs.toString(),
            "sessionMs" to p.sessionMs.toString(),
            "firstFrameMs" to p.firstFrameMs.toString(),
            "frames" to p.frames.toString(),
            "captureFailures" to p.captureFailures.toString(),
            "lumaMean" to String.format(java.util.Locale.US, "%.1f", p.lumaMean),
            "lumaStd" to String.format(java.util.Locale.US, "%.1f", p.lumaStd)
        )
        if (p.lumaMean >= 0 && isBlack(p.lumaMean, p.lumaStd)) {
            details["black"] = "true"
            return TestOutcome(
                TestStatus.WARNING,
                "فریم‌ها رسیدند اما تصویر تقریباً سیاه است (میانگین روشنایی ${details["lumaMean"]}). اگر لنز پوشیده نبود و محیط تاریک نبود، مشکل دریافت تصویر محتمل است.",
                details
            )
        }
        if (p.frames < 5) {
            return TestOutcome(TestStatus.WARNING, "فقط ${p.frames} فریم دریافت شد؛ جریان تصویر ممکن است ناپایدار باشد.", details)
        }
        return TestOutcome(TestStatus.PASSED, "${p.frames} فریم دریافت شد؛ اولین فریم پس از ${p.firstFrameMs}ms.", details)
    }

    // ------------------------------------------------------------------ PHOTO
    suspend fun photo(id: String, thread: CameraThread, t: StageTracker): TestOutcome {
        val closer = Closer()
        try {
            val ch = chars(id, t)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val yuv = pickClosest(map?.getOutputSizes(ImageFormat.YUV_420_888), 640, 480, 1280L * 720)
                ?: throw CameraFailure(ErrorCategory.UNSUPPORTED, "اندازه‌ی خروجی YUV گزارش نشد.", "getCharacteristics")
            val jpegSizes = map?.getOutputSizes(ImageFormat.JPEG)
            if (jpegSizes == null || jpegSizes.isEmpty()) {
                return TestOutcome(TestStatus.UNSUPPORTED, "این دوربین خروجی JPEG گزارش نمی‌کند.", emptyMap(), ErrorCategory.UNSUPPORTED)
            }
            val limit = 12_000_000L
            val jpeg: Size = jpegSizes.filter { it.width.toLong() * it.height <= limit }
                .maxByOrNull { it.width.toLong() * it.height }
                ?: jpegSizes.minByOrNull { it.width.toLong() * it.height }!!

            t.set("openCamera")
            val t0 = SystemClock.elapsedRealtime()
            val cam = openManaged(mgr, id, thread, closer)
            val openMs = elapsed(t0)

            val stats = FrameStats()
            val ready = cam.newWaiter<Unit>()
            val yuvReader = ImageReader.newInstance(yuv.width, yuv.height, ImageFormat.YUV_420_888, 3)
            closer.add { yuvReader.close() }
            closer.add { yuvReader.setOnImageAvailableListener(null, null) }
            yuvReader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    try {
                        if (stats.frames.incrementAndGet() >= 8) ready.complete(Unit)
                    } finally {
                        img.close()
                    }
                }
            }, thread.handler)

            val jpegWaiter = cam.newWaiter<ByteArray>()
            val jpegReader = ImageReader.newInstance(jpeg.width, jpeg.height, ImageFormat.JPEG, 2)
            closer.add { jpegReader.close() }
            closer.add { jpegReader.setOnImageAvailableListener(null, null) }
            jpegReader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireNextImage() } catch (e: Exception) { null }
                if (img != null) {
                    try {
                        val buf = img.planes[0].buffer
                        val bytes = ByteArray(buf.remaining())
                        buf.get(bytes)
                        jpegWaiter.complete(bytes)
                    } finally {
                        img.close()
                    }
                }
            }, thread.handler)

            t.set("createSession")
            val session = createSession(cam, listOf(yuvReader.surface, jpegReader.surface), thread, closer)
            closer.add { session.stopRepeating() }

            t.set("setRepeatingRequest")
            try {
                val pb = cam.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                pb.addTarget(yuvReader.surface)
                applyAuto(pb, ch)
                session.setRepeatingRequest(pb.build(), null, thread.handler)
            } catch (e: CameraAccessException) {
                throw mapAccess(e, "setRepeatingRequest")
            }

            t.set("waitFrames")
            withTimeoutOrNull(6000) { ready.await() }
            if (stats.frames.get() == 0) {
                throw CameraFailure(ErrorCategory.NO_FRAMES, "قبل از ثبت عکس هیچ فریم پیش‌نمایشی دریافت نشد.", "waitFrames")
            }

            t.set("capture")
            val tc = SystemClock.elapsedRealtime()
            try {
                val sb = cam.device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                sb.addTarget(jpegReader.surface)
                applyAuto(sb, ch)
                sb.set(CaptureRequest.JPEG_ORIENTATION, ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0)
                sb.set(CaptureRequest.JPEG_QUALITY, 90.toByte())
                session.capture(sb.build(), object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                        cam.fail(CameraFailure(ErrorCategory.CAPTURE_FAILED, "CaptureFailure (reason=${failure.reason})", "capture"))
                    }
                }, thread.handler)
            } catch (e: CameraAccessException) {
                throw mapAccess(e, "capture")
            }

            t.set("waitImage")
            val bytes = withTimeoutOrNull(8000) { jpegWaiter.await() }
                ?: throw CameraFailure(ErrorCategory.TIMEOUT, "تصویر JPEG تا 8 ثانیه پس از درخواست ثبت نرسید.", "waitImage")
            val captureMs = elapsed(tc)

            t.set("verifyFile")
            val file = samples.newFile("photo_$id", "jpg")
            try {
                file.writeBytes(bytes)
            } catch (e: java.io.IOException) {
                throw CameraFailure(ErrorCategory.IO_FILE, "نوشتن فایل آزمایشی ناموفق بود: ${e.message}", "verifyFile", e)
            }
            if (!file.exists() || file.length() <= 0L) {
                throw CameraFailure(ErrorCategory.INVALID_OUTPUT, "فایل عکس ساخته نشد یا خالی است.", "verifyFile")
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                throw CameraFailure(ErrorCategory.INVALID_OUTPUT, "فایل JPEG قابل‌خواندن نیست (ابعاد نامعتبر).", "verifyFile")
            }
            val details = linkedMapOf(
                "openMs" to openMs.toString(),
                "captureMs" to captureMs.toString(),
                "width" to bounds.outWidth.toString(),
                "height" to bounds.outHeight.toString(),
                "fileBytes" to file.length().toString(),
                "file" to file.name
            )
            val (mean, std) = lumaOfJpeg(file.absolutePath)
            if (mean >= 0) {
                details["lumaMean"] = String.format(java.util.Locale.US, "%.1f", mean)
                if (isBlack(mean, std)) {
                    details["black"] = "true"
                    return TestOutcome(TestStatus.WARNING, "عکس ثبت و خوانده شد اما تقریباً سیاه است. اگر لنز پوشیده نبود، مشکل دریافت تصویر محتمل است.", details)
                }
            }
            return TestOutcome(
                TestStatus.PASSED,
                "عکس ${bounds.outWidth}x${bounds.outHeight} در ${captureMs}ms ثبت شد و فایل معتبر است.",
                details
            )
        } finally {
            closer.closeAll()
        }
    }

    private fun lumaOfJpeg(path: String): Pair<Double, Double> {
        return try {
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 8 }) ?: return -1.0 to -1.0
            var sum = 0.0
            var sumSq = 0.0
            var n = 0
            var y = 0
            while (y < bmp.height) {
                var x = 0
                while (x < bmp.width) {
                    val p = bmp.getPixel(x, y)
                    val l = 0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)
                    sum += l
                    sumSq += l * l
                    n++
                    x += 4
                }
                y += 4
            }
            bmp.recycle()
            if (n == 0) -1.0 to -1.0 else {
                val mean = sum / n
                mean to sqrt(maxOf(0.0, sumSq / n - mean * mean))
            }
        } catch (e: Throwable) {
            -1.0 to -1.0
        }
    }

    // ------------------------------------------------------------------ VIDEO
    suspend fun video(id: String, seconds: Int, withAudio: Boolean, audioNote: String?, thread: CameraThread, t: StageTracker): TestOutcome {
        val closer = Closer()
        try {
            val ch = chars(id, t)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val size = pickClosest(map?.getOutputSizes(MediaRecorder::class.java), 1280, 720, 1920L * 1080)
                ?: return TestOutcome(TestStatus.UNSUPPORTED, "این دوربین اندازه‌ی خروجی MediaRecorder گزارش نمی‌کند.", emptyMap(), ErrorCategory.UNSUPPORTED)

            t.set("openCamera")
            val t0 = SystemClock.elapsedRealtime()
            val cam = openManaged(mgr, id, thread, closer)
            val openMs = elapsed(t0)

            t.set("recorderPrepare")
            val file = samples.newFile("video_$id", "mp4")
            val recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
            closer.add { recorder.release() }
            if (withAudio) recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setOutputFile(file.absolutePath)
            recorder.setVideoEncodingBitRate(4_000_000)
            recorder.setVideoFrameRate(30)
            recorder.setVideoSize(size.width, size.height)
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (withAudio) {
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder.setAudioEncodingBitRate(96_000)
                recorder.setAudioSamplingRate(44_100)
            }
            recorder.setOrientationHint(ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 0)
            recorder.setOnErrorListener { _, what, extra ->
                cam.fail(CameraFailure(ErrorCategory.CAPTURE_FAILED, "خطای MediaRecorder (what=$what, extra=$extra)", "recording"))
            }
            try {
                recorder.prepare()
            } catch (e: java.io.IOException) {
                throw CameraFailure(ErrorCategory.IO_FILE, "آماده‌سازی MediaRecorder ناموفق بود: ${e.message}", "recorderPrepare", e)
            }

            t.set("createSession")
            val session = createSession(cam, listOf(recorder.surface), thread, closer)

            t.set("setRepeatingRequest")
            try {
                val b = cam.device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                b.addTarget(recorder.surface)
                applyAuto(b, ch)
                session.setRepeatingRequest(b.build(), null, thread.handler)
            } catch (e: CameraAccessException) {
                throw mapAccess(e, "setRepeatingRequest")
            }
            delay(300)

            t.set("recorderStart")
            val ts = SystemClock.elapsedRealtime()
            try {
                recorder.start()
            } catch (e: IllegalStateException) {
                throw CameraFailure(ErrorCategory.CAPTURE_FAILED, "شروع ضبط ناموفق بود: ${e.message}", "recorderStart", e)
            }

            t.set("recording")
            val waiter = cam.newWaiter<Unit>()
            withTimeoutOrNull(seconds * 1000L) { waiter.await() } // throws if the camera fails mid-recording
            val wallMs = elapsed(ts)

            t.set("recorderStop")
            try {
                session.stopRepeating()
            } catch (e: Exception) {
            }
            try {
                recorder.stop()
            } catch (e: RuntimeException) {
                throw CameraFailure(ErrorCategory.CAPTURE_FAILED, "توقف ضبط خطا داد (معمولاً یعنی فریم معتبری ضبط نشده): ${e.message}", "recorderStop", e)
            }

            t.set("verifyFile")
            if (!file.exists() || file.length() <= 0L) {
                throw CameraFailure(ErrorCategory.INVALID_OUTPUT, "فایل ویدیو ساخته نشد یا خالی است.", "verifyFile")
            }
            val mmr = MediaMetadataRetriever()
            var durationMs = -1L
            var vw = 0
            var vh = 0
            var hasVideo = false
            try {
                mmr.setDataSource(file.absolutePath)
                durationMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
                vw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                vh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                hasVideo = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            } catch (e: Exception) {
                throw CameraFailure(ErrorCategory.INVALID_OUTPUT, "فایل ویدیو قابل‌خواندن نیست: ${e.javaClass.simpleName}", "verifyFile", e)
            } finally {
                try { mmr.release() } catch (e: Exception) { }
            }
            if (!hasVideo || vw <= 0 || vh <= 0) {
                throw CameraFailure(ErrorCategory.INVALID_OUTPUT, "فایل ویدیو فاقد تصویر معتبر است.", "verifyFile")
            }
            val details = linkedMapOf(
                "openMs" to openMs.toString(),
                "requestedSec" to seconds.toString(),
                "wallMs" to wallMs.toString(),
                "durationMs" to durationMs.toString(),
                "size" to "${vw}x$vh",
                "fileBytes" to file.length().toString(),
                "audio" to (if (withAudio) "yes" else "no"),
                "file" to file.name
            )
            val note = audioNote?.let { " ($it)" } ?: ""
            if (durationMs in 0 until (seconds * 1000L / 2)) {
                return TestOutcome(
                    TestStatus.WARNING,
                    "ویدیو ساخته شد اما مدت واقعی (${durationMs}ms) خیلی کمتر از مدت درخواستی بود$note.", details
                )
            }
            return TestOutcome(TestStatus.PASSED, "ویدیو ${vw}x$vh با مدت ${durationMs}ms ضبط و خوانده شد$note.", details)
        } finally {
            closer.closeAll()
        }
    }

    // ------------------------------------------------------------------ FLASH
    suspend fun flash(id: String, info: CameraInfo?, thread: CameraThread, t: StageTracker, askUser: suspend (String) -> UserAnswer): TestOutcome {
        if (info != null && !info.flashAvailable) {
            return TestOutcome(TestStatus.UNSUPPORTED, "این دوربین فلش ندارد.", emptyMap(), ErrorCategory.UNSUPPORTED)
        }
        val events = Channel<Boolean>(Channel.UNLIMITED)
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == id) events.trySend(enabled)
            }
        }
        var torchOn = false
        t.set("registerTorchCallback")
        mgr.registerTorchCallback(cb, thread.handler)
        try {
            t.set("torchOn")
            try {
                mgr.setTorchMode(id, true)
                torchOn = true
            } catch (e: CameraAccessException) {
                val cat = ErrorClassifier.fromAccessReason(e.reason)
                if (cat == ErrorCategory.IN_USE) {
                    return TestOutcome(TestStatus.INCONCLUSIVE, "قابل‌آزمایش نبود: دوربین/چراغ‌قوه در حال استفاده‌ی برنامه‌ی دیگر است.", emptyMap(), cat)
                }
                throw mapAccess(e, "torchOn")
            }
            t.set("awaitTorchCallback")
            val confirmed = withTimeoutOrNull(3000) {
                var on = false
                while (!on) on = events.receive()
                true
            } ?: false
            if (!confirmed) {
                return TestOutcome(TestStatus.FAILED, "سیستم تغییر وضعیت چراغ‌قوه به «روشن» را گزارش نکرد.", emptyMap(), ErrorCategory.UNKNOWN)
            }
            t.set("askUser")
            val answer = askUser("چراغ‌قوه‌ی گوشی الان روشن شد؟ (در پشت گوشی کنار دوربین نگاه کنید)")
            return when (answer) {
                UserAnswer.YES -> TestOutcome(TestStatus.PASSED, "دستور روشن‌شدن پذیرفته شد و کاربر روشن‌شدن را تأیید کرد.", mapOf("userConfirmed" to "yes"), null, true)
                UserAnswer.NO -> TestOutcome(
                    TestStatus.FAILED,
                    "سیستم روشن‌شدن را گزارش کرد اما کاربر نور ندید (احتمال مشکل سخت‌افزار فلش/اتصال یا پوشش لنز).",
                    mapOf("userConfirmed" to "no"), ErrorCategory.USER_NEGATIVE, true
                )
                UserAnswer.UNKNOWN -> TestOutcome(TestStatus.INCONCLUSIVE, "تأیید کاربر دریافت نشد؛ نتیجه‌ی عملی چراغ‌قوه نامشخص است.", emptyMap())
            }
        } finally {
            if (torchOn) {
                try { mgr.setTorchMode(id, false) } catch (e: Exception) { }
            }
            try { mgr.unregisterTorchCallback(cb) } catch (e: Exception) { }
            events.close()
        }
    }

    // ------------------------------------------------------------------ SWITCH
    suspend fun switchTest(a: String, b: String, cycles: Int, thread: CameraThread, t: StageTracker): TestOutcome {
        val times = ArrayList<String>()
        for (i in 1..cycles) {
            val pa = probe(a, thread, t, targetFrames = 3, waitMs = 4000, prefix = "cycle$i/camera$a:")
            val pb = probe(b, thread, t, targetFrames = 3, waitMs = 4000, prefix = "cycle$i/camera$b:")
            times += "c$i:A=${pa.firstFrameMs}ms,B=${pb.firstFrameMs}ms"
        }
        return TestOutcome(
            TestStatus.PASSED,
            "$cycles بار جابه‌جایی پشت‌سرهم بین دوربین $a و $b بدون خطا انجام شد و در هر مرحله فریم دریافت شد.",
            mapOf("cycles" to cycles.toString(), "firstFrameTimes" to times.joinToString(" | "))
        )
    }
}
