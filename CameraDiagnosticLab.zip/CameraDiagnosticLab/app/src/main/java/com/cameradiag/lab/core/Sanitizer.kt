package com.cameradiag.lab.core

/** Removes values that could identify the user or the file system layout from free text. */
object Sanitizer {
    private val email = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val mac = Regex("\\b([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\\b")
    private val ipv4 = Regex("\\b\\d{1,3}(\\.\\d{1,3}){3}\\b")
    private val path = Regex("/(?:data|storage|sdcard|mnt|proc|sys|system|vendor)/[^\\s,;:)\"']*")
    private val longDigits = Regex("\\b\\d{10,}\\b")

    fun redact(s: String?): String? {
        if (s == null) return null
        var r: String = s
        r = email.replace(r, "<email>")
        r = mac.replace(r, "<mac>")
        r = ipv4.replace(r, "<ip>")
        r = path.replace(r, "<path>")
        r = longDigits.replace(r, "<number>")
        return if (r.length > 600) r.substring(0, 600) + "…" else r
    }
}
