package com.cameradiag.lab.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.withTimeout

class StageTracker {
    @Volatile
    var stage: String? = null
        private set

    fun set(s: String) {
        stage = s
    }
}

data class TestOutcome(
    val status: TestStatus,
    val message: String? = null,
    val details: Map<String, String> = emptyMap(),
    val category: ErrorCategory? = null,
    val userConfirmed: Boolean = false
)

/**
 * Runs one test in a detached worker with a hard timeout.
 * A hung blocking call can never freeze the suite or the UI: on timeout the worker is abandoned
 * (cancelled) and a TIMEOUT result naming the stuck stage is returned.
 */
object Guard {
    suspend fun run(
        kind: TestKind,
        cameraId: String,
        timeoutMs: Long,
        clock: () -> Long = { System.currentTimeMillis() },
        dispatcher: CoroutineDispatcher = Dispatchers.Default,
        onCancelled: (TestResult) -> Unit = {},
        block: suspend (StageTracker) -> TestOutcome
    ): TestResult {
        val tracker = StageTracker()
        val started = clock()
        val worker = CoroutineScope(SupervisorJob() + dispatcher).async { block(tracker) }

        fun build(
            status: TestStatus,
            category: ErrorCategory?,
            message: String?,
            details: Map<String, String>,
            error: Throwable?,
            stage: String?,
            confirmed: Boolean = false
        ) = TestResult(
            kind = kind,
            cameraId = cameraId,
            status = status,
            stage = stage,
            durationMs = clock() - started,
            category = category,
            exceptionType = error?.javaClass?.name,
            message = Sanitizer.redact(message),
            details = details,
            stackTop = if (error != null && category != ErrorCategory.TIMEOUT) ErrorClassifier.stackTop(error) else emptyList(),
            timestampMillis = started,
            userConfirmed = confirmed
        )

        try {
            val o = withTimeout(timeoutMs) { worker.await() }
            return build(o.status, o.category, o.message, o.details, null, tracker.stage, o.userConfirmed)
        } catch (e: TimeoutCancellationException) {
            worker.cancel()
            return build(
                TestStatus.FAILED, ErrorCategory.TIMEOUT,
                "آزمایش در مرحله‌ی «${tracker.stage ?: "نامشخص"}» پاسخی نداد (Timeout ${timeoutMs} ms).",
                emptyMap(), null, tracker.stage
            )
        } catch (e: CancellationException) {
            worker.cancel()
            onCancelled(
                build(
                    TestStatus.NOT_TESTED, ErrorCategory.CANCELLED,
                    "آزمایش توسط کاربر یا سیستم لغو شد (مرحله: ${tracker.stage ?: "شروع نشده"}).",
                    emptyMap(), null, tracker.stage
                )
            )
            throw e
        } catch (e: Exception) {
            val cat = ErrorClassifier.fromThrowable(e)
            val stage = tracker.stage ?: (e as? CameraFailure)?.stage
            return build(TestStatus.FAILED, cat, e.message ?: e.javaClass.simpleName, emptyMap(), e, stage)
        }
    }
}
