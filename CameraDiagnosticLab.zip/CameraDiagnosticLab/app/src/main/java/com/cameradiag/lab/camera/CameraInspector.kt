package com.cameradiag.lab.camera

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import com.cameradiag.lab.core.CameraInfo
import com.cameradiag.lab.core.LensFacing

object CameraInspector {
    data class Result(val cameras: List<CameraInfo>, val error: String?)

    private val CAPABILITY_NAMES = mapOf(
        0 to "BACKWARD_COMPATIBLE", 1 to "MANUAL_SENSOR", 2 to "MANUAL_POST_PROCESSING", 3 to "RAW",
        4 to "PRIVATE_REPROCESSING", 5 to "READ_SENSOR_SETTINGS", 6 to "BURST_CAPTURE", 7 to "YUV_REPROCESSING",
        8 to "DEPTH_OUTPUT", 9 to "CONSTRAINED_HIGH_SPEED_VIDEO", 10 to "MOTION_TRACKING",
        11 to "LOGICAL_MULTI_CAMERA", 12 to "MONOCHROME", 13 to "SECURE_IMAGE_DATA",
        14 to "SYSTEM_CAMERA", 15 to "OFFLINE_PROCESSING"
    )

    fun inspect(context: Context): Result {
        val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids: Array<String> = try {
            mgr.cameraIdList
        } catch (e: CameraAccessException) {
            return Result(emptyList(), "CameraAccessException (reason=${e.reason}): ${e.message}")
        } catch (e: Exception) {
            return Result(emptyList(), "${e.javaClass.simpleName}: ${e.message}")
        }
        val list = ids.map { id ->
            try {
                describe(mgr, id)
            } catch (e: Exception) {
                CameraInfo(
                    id = id, lensFacing = LensFacing.UNKNOWN, flashAvailable = false, hardwareLevel = "نامشخص",
                    capabilities = emptyList(), sensorOrientation = null, maxJpegSize = null, physicalCameraIds = emptyList(),
                    note = "خواندن مشخصات ناموفق بود: ${e.javaClass.simpleName}"
                )
            }
        }
        return Result(list, null)
    }

    private fun describe(mgr: CameraManager, id: String): CameraInfo {
        val ch = mgr.getCameraCharacteristics(id)
        val facing = when (ch.get(CameraCharacteristics.LENS_FACING)) {
            CameraMetadata.LENS_FACING_BACK -> LensFacing.BACK
            CameraMetadata.LENS_FACING_FRONT -> LensFacing.FRONT
            CameraMetadata.LENS_FACING_EXTERNAL -> LensFacing.EXTERNAL
            else -> LensFacing.UNKNOWN
        }
        val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val level = when (ch.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            else -> "نامشخص"
        }
        val caps = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.map { CAPABILITY_NAMES[it] ?: "CAP_$it" } ?: emptyList()
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val maxJpeg = map?.getOutputSizes(ImageFormat.JPEG)
            ?.maxByOrNull { it.width.toLong() * it.height }
            ?.let { "${it.width}x${it.height}" }
        val physical = try {
            ch.physicalCameraIds.toList()
        } catch (e: Exception) {
            emptyList()
        }
        return CameraInfo(
            id = id, lensFacing = facing, flashAvailable = flash, hardwareLevel = level,
            capabilities = caps, sensorOrientation = ch.get(CameraCharacteristics.SENSOR_ORIENTATION),
            maxJpegSize = maxJpeg, physicalCameraIds = physical
        )
    }
}
