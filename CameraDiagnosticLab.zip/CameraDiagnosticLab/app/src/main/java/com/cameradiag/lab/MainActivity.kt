package com.cameradiag.lab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.cameradiag.lab.ui.DiagApp
import kotlinx.coroutines.CompletableDeferred

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var permDeferred: CompletableDeferred<Boolean>? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permDeferred?.complete(granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vm.permissionRequester = { p -> requestPermissionSuspending(p) }
        setContent { DiagApp(vm) { intent -> startActivity(intent) } }
    }

    private suspend fun requestPermissionSuspending(permission: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        permDeferred = d
        vm.waitingForPermission = true
        try {
            permLauncher.launch(permission)
            return d.await()
        } finally {
            vm.waitingForPermission = false
        }
    }

    override fun onStart() {
        super.onStart()
        vm.refreshAll()
    }

    override fun onStop() {
        super.onStop()
        if (!vm.waitingForPermission) vm.onAppBackgrounded()
    }

    override fun onDestroy() {
        vm.permissionRequester = null
        super.onDestroy()
    }
}
