package com.cameradiag.lab.camera

import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Surface
import com.cameradiag.lab.core.CameraFailure
import com.cameradiag.lab.core.ErrorCategory
import com.cameradiag.lab.core.ErrorClassifier
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class CameraThread(name: String = "diag-camera") {
    private val thread = HandlerThread(name).also { it.start() }
    val handler: Handler = Handler(thread.looper)
    val executor: Executor = Executor { command -> handler.post(command) }
    fun close() {
        try {
            thread.quitSafely()
        } catch (e: Exception) {
        }
    }
}

/** Collects release actions and runs them in reverse order. Late additions after closeAll run immediately. */
class Closer {
    private val items = ArrayDeque<() -> Unit>()
    private var closed = false

    @Synchronized
    fun add(action: () -> Unit) {
        if (closed) run(action) else items.addLast(action)
    }

    @Synchronized
    fun closeAll() {
        closed = true
        while (items.isNotEmpty()) run(items.removeLast())
    }

    private fun run(action: () -> Unit) {
        try {
            action()
        } catch (e: Throwable) {
        }
    }
}

/** An opened camera. Asynchronous failures (disconnect, error, capture failure) complete every waiter exceptionally. */
class ManagedCamera(val device: CameraDevice) {
    private val waiters = CopyOnWriteArrayList<CompletableDeferred<*>>()

    @Volatile
    var failure: CameraFailure? = null
        private set

    fun <T> newWaiter(): CompletableDeferred<T> {
        val d = CompletableDeferred<T>()
        val f = failure
        if (f != null) d.completeExceptionally(f)
        waiters.add(d)
        return d
    }

    fun fail(f: CameraFailure) {
        if (failure == null) failure = f
        waiters.forEach { it.completeExceptionally(f) }
    }

    fun close() {
        try {
            device.close()
        } catch (e: Exception) {
        }
    }
}

fun mapAccess(e: CameraAccessException, stage: String): CameraFailure =
    CameraFailure(ErrorClassifier.fromAccessReason(e.reason), "CameraAccessException (reason=${e.reason}): ${e.message}", stage, e)

suspend fun openManaged(mgr: CameraManager, id: String, thread: CameraThread, closer: Closer): ManagedCamera =
    suspendCancellableCoroutine { cont ->
        var managed: ManagedCamera? = null
        val cb = object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                val m = ManagedCamera(camera)
                managed = m
                closer.add { m.close() }
                if (cont.isActive) cont.resume(m) else m.close()
            }

            override fun onDisconnected(camera: CameraDevice) {
                val f = CameraFailure(ErrorCategory.DISCONNECTED, "دوربین قطع شد (onDisconnected).", "openCamera")
                val m = managed
                if (m != null) m.fail(f) else if (cont.isActive) cont.resumeWithException(f)
                try {
                    camera.close()
                } catch (e: Exception) {
                }
            }

            override fun onError(camera: CameraDevice, error: Int) {
                val f = CameraFailure(ErrorClassifier.fromDeviceStateError(error), "خطای CameraDevice با کد $error.", "openCamera")
                val m = managed
                if (m != null) m.fail(f) else if (cont.isActive) cont.resumeWithException(f)
                try {
                    camera.close()
                } catch (e: Exception) {
                }
            }
        }
        try {
            mgr.openCamera(id, cb, thread.handler)
        } catch (e: CameraAccessException) {
            if (cont.isActive) cont.resumeWithException(mapAccess(e, "openCamera"))
        } catch (e: SecurityException) {
            if (cont.isActive) cont.resumeWithException(CameraFailure(ErrorCategory.PERMISSION, "SecurityException: ${e.message}", "openCamera", e))
        } catch (e: IllegalArgumentException) {
            if (cont.isActive) cont.resumeWithException(CameraFailure(ErrorCategory.UNKNOWN, "IllegalArgumentException: ${e.message}", "openCamera", e))
        }
        cont.invokeOnCancellation { managed?.close() }
    }

suspend fun createSession(cam: ManagedCamera, surfaces: List<Surface>, thread: CameraThread, closer: Closer): CameraCaptureSession =
    suspendCancellableCoroutine { cont ->
        val cb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                closer.add { session.close() }
                if (cont.isActive) cont.resume(session) else session.close()
            }

            override fun onConfigureFailed(session: CameraCaptureSession) {
                if (cont.isActive) cont.resumeWithException(CameraFailure(ErrorCategory.SESSION_CONFIG, "onConfigureFailed: ساخت Session ناموفق بود.", "createSession"))
            }
        }
        try {
            val outputs = surfaces.map { OutputConfiguration(it) }
            val cfg = SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outputs, thread.executor, cb)
            cam.device.createCaptureSession(cfg)
        } catch (e: CameraAccessException) {
            if (cont.isActive) cont.resumeWithException(mapAccess(e, "createSession"))
        } catch (e: IllegalArgumentException) {
            if (cont.isActive) cont.resumeWithException(CameraFailure(ErrorCategory.SESSION_CONFIG, "IllegalArgumentException: ${e.message}", "createSession", e))
        } catch (e: IllegalStateException) {
            if (cont.isActive) cont.resumeWithException(CameraFailure(ErrorCategory.DISCONNECTED, "IllegalStateException: ${e.message}", "createSession", e))
        }
    }

fun applyAuto(b: CaptureRequest.Builder, chars: CameraCharacteristics) {
    b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
    val af = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
    if (af != null && af.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)) {
        b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
    }
}

fun pickClosest(sizes: Array<Size>?, targetW: Int, targetH: Int, maxArea: Long = Long.MAX_VALUE): Size? {
    if (sizes == null || sizes.isEmpty()) return null
    val target = targetW.toLong() * targetH
    val within = sizes.filter { it.width.toLong() * it.height <= maxArea }
    val pool = if (within.isEmpty()) sizes.toList() else within
    return pool.minByOrNull { abs(it.width.toLong() * it.height - target) }
}

class FrameStats {
    val frames = AtomicInteger(0)
    val captureFailures = AtomicInteger(0)

    @Volatile var firstFrameAt: Long = 0L
    @Volatile var lumaMean: Double = -1.0
    @Volatile var lumaStd: Double = -1.0
}

fun computeLuma(img: Image, stats: FrameStats) {
    val plane = img.planes[0]
    val buf = plane.buffer
    val rowStride = plane.rowStride
    val pixStride = plane.pixelStride
    var sum = 0.0
    var sumSq = 0.0
    var n = 0
    var y = 0
    while (y < img.height) {
        var x = 0
        while (x < img.width) {
            val idx = y * rowStride + x * pixStride
            if (idx < buf.limit()) {
                val v = buf.get(idx).toInt() and 0xFF
                sum += v
                sumSq += (v * v).toDouble()
                n++
            }
            x += 16
        }
        y += 16
    }
    if (n > 0) {
        val mean = sum / n
        stats.lumaMean = mean
        stats.lumaStd = sqrt(max(0.0, sumSq / n - mean * mean))
    }
}

fun isBlack(mean: Double, std: Double): Boolean = mean in 0.0..12.0 && std in 0.0..4.0
