package com.cameradiag.lab.core

/**
 * Rule-based analysis. It only reasons about results that really exist.
 * It never reports "healthy": the best possible overall state is PASSED_TESTED_PATHS.
 * Hardware-related causes are capped at MEDIUM confidence because software cannot inspect hardware.
 */
object RuleEngine {

    val LIMITATIONS: List<String> = listOf(
        "موفق‌بودن مسیر Camera2 این برنامه، سلامت کامل برنامه‌ی دوربین کارخانه‌ای را ثابت نمی‌کند (برنامه‌ی اصلی از مسیرها و قابلیت‌های اختصاصی سازنده استفاده می‌کند).",
        "برنامه‌ی عادی اندروید به Logcat کامل سیستم دسترسی ندارد؛ خطاهای عمیق سیستمی فقط با Bug Report رسمی اندروید دیده می‌شوند.",
        "پاسخ‌های «گزارش کاربر» اندازه‌گیری مستقیم نیستند و فقط به‌عنوان شاهد کمکی استفاده می‌شوند.",
        "نرم‌افزار نمی‌تواند فلت معیوب را از ماژول معیوب یا مشکل مادربرد جدا کند؛ تشخیص قطعی سخت‌افزار فقط با بازرسی فیزیکی ممکن است.",
        "تصویر تقریباً سیاه ممکن است به‌علت پوشیده‌بودن لنز یا تاریکی محیط باشد.",
        "فقط دوربین‌هایی که سازنده از طریق Camera2 در دسترس برنامه‌های عادی قرار داده، قابل آزمایش‌اند."
    )

    private fun TestResult.cat(vararg c: ErrorCategory): Boolean = category != null && c.contains(category)

    fun analyze(input: AnalysisInput): Analysis {
        val cams = input.cameras
        val all = input.results
        val auto = all.filter { !it.manual }
        val facing = cams.associate { it.id to it.lensFacing }

        fun primary(kind: TestKind, id: String): TestResult? =
            auto.lastOrNull { it.kind == kind && it.cameraId == id }
                ?: all.lastOrNull { it.kind == kind && it.cameraId == id }

        fun lbl(id: String): String = Labels.camera(id, facing[id])
        fun desc(r: TestResult): String {
            val sb = StringBuilder("${Labels.kind(r.kind)} ${lbl(r.cameraId)}: ${Labels.status(r.status)}")
            if (r.category != null) sb.append(" — ").append(Labels.category(r.category))
            if (r.stage != null) sb.append(" (مرحله: ${r.stage})")
            return sb.toString()
        }

        val ran = all.filter { it.executed }
        val failed = all.filter { it.status == TestStatus.FAILED }
        val findings = mutableListOf<Finding>()
        val user = input.user
        val afterRepair = user.answer(UserQuestions.AFTER_REPAIR) == UserAnswer.YES

        // ---------- Overall ----------
        val overall = when {
            failed.isNotEmpty() -> OverallStatus.ISSUES_FOUND
            ran.isEmpty() -> OverallStatus.NO_DATA
            else -> {
                val allCore = cams.isNotEmpty() && cams.all { cam ->
                    listOf(TestKind.OPEN, TestKind.PREVIEW, TestKind.PHOTO).all { k ->
                        primary(k, cam.id)?.status == TestStatus.PASSED
                    }
                }
                val noSoft = all.none { it.status == TestStatus.WARNING || it.status == TestStatus.INCONCLUSIVE }
                if (allCore && noSoft) OverallStatus.PASSED_TESTED_PATHS else OverallStatus.PARTIAL
            }
        }

        // ---------- 1. Access ----------
        val permDenied = input.cameraPermissionGranted == false
        val accessFails = all.filter {
            it.status != TestStatus.PASSED && it.cat(ErrorCategory.PERMISSION, ErrorCategory.SECURITY, ErrorCategory.IN_USE, ErrorCategory.DISABLED)
        }
        if (permDenied || accessFails.isNotEmpty()) {
            val f = mutableListOf<String>()
            val a = mutableListOf<String>()
            if (permDenied) f += "مجوز دوربین به برنامه داده نشده است؛ آزمایش‌های دوربین اجرا نشده‌اند."
            accessFails.filter { !permDenied || it.category != ErrorCategory.PERMISSION }.take(6).forEach { f += desc(it) }
            if (!permDenied && ran.isNotEmpty()) a += "${ran.size} آزمایش اجرا شده است؛ پس دسترسی دست‌کم برای بخشی از آزمایش‌ها ممکن بوده است."
            val conf = when {
                permDenied -> Confidence.HIGH
                accessFails.size >= 2 -> Confidence.MEDIUM
                else -> Confidence.LOW
            }
            findings += Finding(
                Cause.ACCESS, conf, f, a,
                if (permDenied) "مجوز دوربین را از تنظیمات برنامه بدهید و آزمایش را دوباره اجرا کنید."
                else "برنامه‌هایی را که ممکن است دوربین را اشغال کرده باشند ببندید (یا گوشی را ریستارت کنید) و آزمایش را تکرار کنید."
            )
        }

        // ---------- no cameras ----------
        if (cams.isEmpty() && !permDenied) {
            val f = mutableListOf("Camera2 هیچ دوربینی را به برنامه گزارش نکرد.")
            if (input.cameraListError != null) f += "خطای دریافت فهرست دوربین‌ها: ${Sanitizer.redact(input.cameraListError)}"
            findings += Finding(
                Cause.CAMERA_SERVICE,
                if (input.cameraListError != null) Confidence.MEDIUM else Confidence.LOW,
                f,
                if (input.cameraListError == null) listOf("خطای صریحی هنگام فهرست‌کردن ثبت نشد.") else emptyList(),
                "گوشی را ریستارت کنید، سپس دوباره آزمایش کنید. اگر برنامه‌ی دوربین اصلی هم کار نمی‌کند، بررسی توسط تعمیرکار را در نظر بگیرید."
            )
        }

        // ---------- 2. Camera service ----------
        val serviceFails = all.filter {
            it.status == TestStatus.FAILED && it.cat(ErrorCategory.SERVICE_ERROR, ErrorCategory.DISCONNECTED)
        }
        val switchFails = all.filter { it.kind == TestKind.SWITCH && it.status == TestStatus.FAILED }
        if (serviceFails.isNotEmpty() || switchFails.isNotEmpty() || (input.cameraListError != null && cams.isNotEmpty())) {
            val f = mutableListOf<String>()
            val a = mutableListOf<String>()
            serviceFails.take(6).forEach { f += desc(it) }
            switchFails.filter { it !in serviceFails }.forEach { f += desc(it) + " — مشکل هنگام جابه‌جایی پشت‌سرهم بین دوربین‌ها" }
            val openOk = all.filter { it.kind == TestKind.OPEN && it.status == TestStatus.PASSED }
            if (openOk.isNotEmpty()) a += "بازشدن دوربین برای ${openOk.size} دوربین موفق بود."
            val everyOpenFailed = cams.isNotEmpty() && cams.all { primary(TestKind.OPEN, it.id)?.let { r -> r.status == TestStatus.FAILED } == true }
            findings += Finding(
                Cause.CAMERA_SERVICE,
                if (serviceFails.isNotEmpty() && everyOpenFailed) Confidence.MEDIUM else Confidence.LOW,
                f, a,
                "گوشی را ریستارت کنید و آزمایش را تکرار کنید؛ سپس یک بار در حالت Safe Mode آزمایش کنید تا نقش برنامه‌های شخص ثالث روشن شود."
            )
        }

        // ---------- 3. Session creation ----------
        val sessionFails = all.filter {
            it.status == TestStatus.FAILED && (it.cat(ErrorCategory.SESSION_CONFIG) || (it.stage?.endsWith("createSession") == true))
        }
        if (sessionFails.isNotEmpty()) {
            val camsAffected = sessionFails.map { it.cameraId }.distinct()
            val a = mutableListOf<String>()
            camsAffected.forEach { id ->
                if (primary(TestKind.OPEN, id)?.status == TestStatus.PASSED) a += "بازشدن ${lbl(id)} موفق بوده؛ یعنی دوربین باز می‌شود ولی ساخت Session شکست می‌خورد."
            }
            val otherOk = cams.filter { it.id !in camsAffected && primary(TestKind.PREVIEW, it.id)?.status == TestStatus.PASSED }
            if (otherOk.isNotEmpty()) a += "پیش‌نمایش ${otherOk.joinToString("، ") { lbl(it.id) }} موفق بود؛ مشکل مختص دوربین/ترکیب خروجی خاصی است."
            val sameCamTwice = sessionFails.groupBy { it.cameraId }.any { it.value.size >= 2 }
            findings += Finding(
                Cause.SESSION_CREATION,
                if (sameCamTwice) Confidence.HIGH else Confidence.MEDIUM,
                sessionFails.take(6).map { desc(it) }, a,
                "آزمایش را تکرار کنید و در صورت تداوم، Bug Report رسمی اندروید را (راهنما → Bug Report) هنگام بروز خطا تهیه کنید."
            )
        }

        // ---------- 5. Image pipeline ----------
        val pipeCams = cams.filter { cam ->
            primary(TestKind.PREVIEW, cam.id)?.status == TestStatus.PASSED &&
                listOf(TestKind.PHOTO, TestKind.VIDEO).any { k ->
                    val r = primary(k, cam.id)
                    r != null && r.status == TestStatus.FAILED && !(r.cat(ErrorCategory.SESSION_CONFIG, ErrorCategory.PERMISSION)) && r.stage?.endsWith("createSession") != true
                }
        }
        if (pipeCams.isNotEmpty()) {
            val f = mutableListOf<String>()
            val a = mutableListOf<String>()
            pipeCams.forEach { cam ->
                f += "پیش‌نمایش ${lbl(cam.id)} موفق بود (فریم‌ها می‌رسند)؛ اما " + listOf(TestKind.PHOTO, TestKind.VIDEO)
                    .mapNotNull { primary(it, cam.id) }.filter { it.status == TestStatus.FAILED }.joinToString("، ") { desc(it) }
                if (primary(TestKind.OPEN, cam.id)?.status == TestStatus.PASSED) a += "بازشدن ${lbl(cam.id)} بدون خطا بود."
            }
            if (user.answer(UserQuestions.PHOTO_BROKEN_VIDEO_OK) == UserAnswer.YES) f += "[گزارش کاربر] عکاسی مشکل دارد ولی فیلم‌برداری کار می‌کند."
            findings += Finding(
                Cause.IMAGE_PIPELINE, Confidence.MEDIUM, f, a,
                "آزمایش عکاسی را یک بار دیگر تکرار کنید تا مشخص شود خطا پایدار است یا گهگاهی."
            )
        }

        // ---------- 4. App software ----------
        val coreOkCams = cams.filter { cam ->
            listOf(TestKind.OPEN, TestKind.PREVIEW, TestKind.PHOTO).all { primary(it, cam.id)?.status == TestStatus.PASSED }
        }
        if (coreOkCams.isNotEmpty() && user.reportsStockProblem()) {
            val f = mutableListOf<String>()
            val a = mutableListOf<String>()
            f += "بازشدن، پیش‌نمایش و عکاسی از مسیر Camera2 برای ${coreOkCams.joinToString("، ") { lbl(it.id) }} بدون خطا انجام شد."
            if (all.any { it.kind == TestKind.SWITCH && it.status == TestStatus.PASSED }) f += "تعویض سریع بین دوربین‌ها هم بدون خطا بود."
            f += "[گزارش کاربر] برنامه‌ی دوربین اصلی مشکل دارد."
            if (user.answer(UserQuestions.CLEAR_DATA_CHANGED) == UserAnswer.YES) f += "[گزارش کاربر] پاک‌کردن داده/حافظه‌ی موقت برنامه‌ی دوربین رفتار را تغییر داده (نشانه‌ی وابستگی به وضعیت نرم‌افزار)."
            a += "موفقیت Camera2 تنها یک مسیر را نشان می‌دهد؛ برنامه‌ی اصلی از قابلیت‌های اختصاصی سازنده استفاده می‌کند و ممکن است همچنان مشکل داشته باشد."
            if (afterRepair) a += "[گزارش کاربر] مشکل بعد از تعمیر شروع شده؛ این با علت صرفاً نرم‌افزاری کاملاً هم‌خوان نیست."
            findings += Finding(
                Cause.APP_SOFTWARE, Confidence.MEDIUM, f, a,
                "ابتدا مراحل نرم‌افزاری (راهنمای رفع مشکل) را انجام دهید: به‌روزرسانی سیستم/برنامه‌ی دوربین، بررسی در Safe Mode و در صورت نیاز نصب مجدد نرم‌افزار سیستم."
            )
        }

        // ---------- 6/7. Flex / module ----------
        data class Sig(val id: String, val text: String, val flex: Boolean, val module: Boolean)
        val sigs = mutableListOf<Sig>()
        for (r in all) {
            when {
                r.kind == TestKind.OPEN && r.status == TestStatus.FAILED && r.cat(ErrorCategory.DEVICE_ERROR, ErrorCategory.DISCONNECTED) ->
                    sigs += Sig(r.cameraId, desc(r), flex = true, module = false)
                r.kind == TestKind.OPEN && r.status == TestStatus.FAILED && r.cat(ErrorCategory.TIMEOUT) ->
                    sigs += Sig(r.cameraId, desc(r), flex = true, module = false)
                r.status == TestStatus.FAILED && r.cat(ErrorCategory.NO_FRAMES) ->
                    sigs += Sig(r.cameraId, desc(r), flex = false, module = true)
                r.status == TestStatus.WARNING && r.details["black"] == "true" ->
                    sigs += Sig(r.cameraId, "${Labels.kind(r.kind)} ${lbl(r.cameraId)}: تصویر تقریباً سیاه دریافت شد", flex = false, module = true)
                r.kind == TestKind.PREVIEW && r.status == TestStatus.FAILED && r.cat(ErrorCategory.USER_NEGATIVE) ->
                    sigs += Sig(r.cameraId, "[گزارش کاربر] ${lbl(r.cameraId)}: پیش‌نمایش دستی سیاه/خراب بود", flex = false, module = true)
            }
        }
        fun otherCameraOk(ids: Set<String>): Boolean =
            cams.any { it.id !in ids && primary(TestKind.OPEN, it.id)?.status == TestStatus.PASSED && primary(TestKind.PREVIEW, it.id)?.status == TestStatus.PASSED }

        fun hwFinding(cause: Cause, selected: List<Sig>, extra: String) {
            if (selected.isEmpty() && !(afterRepair && sigs.isNotEmpty())) return
            val use = if (selected.isNotEmpty()) selected else sigs
            val ids = use.map { it.id }.toSet()
            val f = use.map { it.text }.distinct().toMutableList()
            if (afterRepair) f += "[گزارش کاربر] مشکل بعد از تعمیر/تعویض قطعه شروع شده است."
            if (user.answer(UserQuestions.REAR_BLACK) == UserAnswer.YES) f += "[گزارش کاربر] برنامه‌ی دوربین اصلی هم تصویر سیاه نشان می‌دهد."
            val a = mutableListOf<String>()
            ids.forEach { id ->
                if (primary(TestKind.PHOTO, id)?.status == TestStatus.PASSED) a += "ثبت عکس با ${lbl(id)} موفق بود."
            }
            a += "نرم‌افزار قادر به بازرسی فیزیکی نیست؛ این یک احتمال است، نه تشخیص قطعی."
            val conf = if (otherCameraOk(ids) && use.any { it.flex || it.module }) Confidence.MEDIUM else Confidence.LOW
            if (otherCameraOk(ids)) f += "دوربین دیگری با همین برنامه به‌درستی باز شد و تصویر داد؛ مشکل مختص دوربین/مسیر اتصال همان دوربین به نظر می‌رسد."
            findings += Finding(cause, conf, f, a, extra)
        }
        hwFinding(
            Cause.CONNECTION_FLEX, sigs.filter { it.flex },
            "اگر گوشی اخیراً باز شده (مثلاً تعویض نمایشگر)، از تعمیرکار بخواهید اتصال کانکتور/فلت دوربین را بازبینی کند."
        )
        hwFinding(
            Cause.CAMERA_MODULE, sigs.filter { it.module },
            "آزمایش را با لنز کاملاً باز و در نور کافی تکرار کنید؛ در صورت تداوم سیاه‌بودن، بررسی ماژول دوربین توسط تعمیرکار را در نظر بگیرید."
        )

        // ---------- 8. API limitation ----------
        val unsupported = all.filter { it.status == TestStatus.UNSUPPORTED && it.kind != TestKind.FLASH }
        if (unsupported.isNotEmpty()) {
            findings += Finding(
                Cause.API_LIMITATION, Confidence.LOW,
                unsupported.take(6).map { desc(it) },
                listOf("پشتیبانی‌نشدن به‌معنای خرابی نیست و به‌عنوان خرابی ثبت نشده است."),
                "این موارد را با تنظیمات یا آزمایش دستی بررسی کنید."
            )
        }

        // ---------- 9. Inconclusive ----------
        val softResults = all.filter { it.status == TestStatus.INCONCLUSIVE || it.status == TestStatus.WARNING }
        if (findings.isEmpty() || overall == OverallStatus.NO_DATA || overall == OverallStatus.PARTIAL || overall == OverallStatus.PASSED_TESTED_PATHS) {
            val f = mutableListOf<String>()
            when (overall) {
                OverallStatus.NO_DATA -> f += "هیچ آزمایش واقعی اجرا نشده یا نتیجه‌ای ثبت نشده است."
                OverallStatus.PASSED_TESTED_PATHS -> f += "در مسیرهای آزمایش‌شده خطایی دیده نشد؛ این به‌معنای تأیید سلامت کامل دوربین نیست."
                OverallStatus.PARTIAL -> f += "بخشی از آزمایش‌ها انجام نشده، هشدار داده یا نامشخص مانده‌اند."
                OverallStatus.ISSUES_FOUND -> f += "برخی خطاها با قاعده‌های موجود به علت مشخصی نسبت داده نشد."
            }
            softResults.take(6).forEach { f += desc(it) }
            val notTested = all.filter { it.status == TestStatus.NOT_TESTED }
            if (notTested.isNotEmpty()) f += "${notTested.size} آزمایش انجام نشده است."
            val addInconclusive = overall != OverallStatus.ISSUES_FOUND || findings.isEmpty()
            if (addInconclusive) {
                findings += Finding(
                    Cause.INCONCLUSIVE, Confidence.UNDETERMINED, f, emptyList(),
                    if (overall == OverallStatus.PASSED_TESTED_PATHS) "اگر برنامه‌ی دوربین اصلی هنوز مشکل دارد، «گزارش دستی خرابی» را پر کنید و آزمایش را بعد از بروز مشکل تکرار کنید."
                    else "آزمایش کامل را (با همه‌ی مجوزها) اجرا کنید و «گزارش دستی خرابی» را تکمیل کنید."
                )
            }
        }

        // ---------- Repair advice ----------
        val hwStrong = findings.any { (it.cause == Cause.CONNECTION_FLEX || it.cause == Cause.CAMERA_MODULE) && it.confidence >= Confidence.MEDIUM }
        val softMid = findings.any {
            (it.cause == Cause.CAMERA_SERVICE || it.cause == Cause.SESSION_CREATION || it.cause == Cause.IMAGE_PIPELINE) && it.confidence >= Confidence.MEDIUM
        }
        val (advice, note) = when {
            hwStrong -> RepairAdvice.RECOMMENDED to
                "الگوی خطاها (مختص یک دوربین، همراه با نبود فریم/قطع‌شدن) با مشکل اتصال یا ماژول سازگار است. توصیه می‌شود دوربین پشت توسط تعمیرکار بازبینی شود؛ این یک احتمال است، نه تشخیص قطعی."
            cams.isEmpty() && !permDenied -> RepairAdvice.CONSIDER to
                "هیچ دوربینی گزارش نشد. پس از ریستارت و آزمایش مجدد، اگر برنامه‌ی دوربین اصلی هم کار نمی‌کند بررسی تعمیرکار را در نظر بگیرید."
            softMid || failed.isNotEmpty() -> RepairAdvice.CONSIDER to
                "ابتدا مراحل نرم‌افزاری را امتحان کنید. اگر مشکل پایدار ماند، به‌ویژه پس از تعمیر سخت‌افزاری، تعمیرکار را در جریان بگذارید."
            findings.any { it.cause == Cause.APP_SOFTWARE } -> RepairAdvice.NOT_INDICATED_YET to
                "مسیر Camera2 مشکلی نشان نداد؛ ابتدا راه‌حل‌های نرم‌افزاری را امتحان کنید. اگر مشکل بعد از تعمیر آغاز شده، گزینه‌ی تعمیرکار را کنار نگذارید."
            overall == OverallStatus.PASSED_TESTED_PATHS -> RepairAdvice.NOT_INDICATED_YET to
                "در مسیرهای آزمایش‌شده خطایی دیده نشد. این تأیید سلامت کامل نیست."
            else -> RepairAdvice.UNDETERMINED to "داده برای تصمیم‌گیری کافی نیست؛ آزمایش کامل را اجرا کنید."
        }

        val sorted = findings.sortedWith(compareByDescending<Finding> { it.confidence }.thenBy { it.cause.ordinal })
        return Analysis(overall, sorted, advice, note, LIMITATIONS)
    }
}
