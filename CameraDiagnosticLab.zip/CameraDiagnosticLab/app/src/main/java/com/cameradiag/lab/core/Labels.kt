package com.cameradiag.lab.core

object Labels {
    fun kind(k: TestKind): String = when (k) {
        TestKind.OPEN -> "بازشدن دوربین"
        TestKind.PREVIEW -> "پیش‌نمایش"
        TestKind.PHOTO -> "عکاسی"
        TestKind.VIDEO -> "فیلم‌برداری"
        TestKind.FLASH -> "چراغ‌قوه"
        TestKind.SWITCH -> "تعویض سریع دوربین"
    }

    fun status(s: TestStatus): String = when (s) {
        TestStatus.PASSED -> "موفق"
        TestStatus.FAILED -> "ناموفق"
        TestStatus.WARNING -> "هشدار"
        TestStatus.NOT_TESTED -> "انجام نشد"
        TestStatus.UNSUPPORTED -> "پشتیبانی نمی‌شود"
        TestStatus.INCONCLUSIVE -> "نامشخص"
    }

    fun facing(f: LensFacing): String = when (f) {
        LensFacing.BACK -> "پشت"
        LensFacing.FRONT -> "سلفی"
        LensFacing.EXTERNAL -> "خارجی"
        LensFacing.UNKNOWN -> "نامشخص"
    }

    fun category(c: ErrorCategory): String = when (c) {
        ErrorCategory.PERMISSION -> "مجوز داده نشده"
        ErrorCategory.SECURITY -> "خطای امنیتی/دسترسی"
        ErrorCategory.IN_USE -> "دوربین اشغال است"
        ErrorCategory.DISABLED -> "دوربین غیرفعال شده است"
        ErrorCategory.DISCONNECTED -> "قطع‌شدن دوربین"
        ErrorCategory.DEVICE_ERROR -> "خطای دستگاه دوربین"
        ErrorCategory.SERVICE_ERROR -> "خطای سرویس دوربین اندروید"
        ErrorCategory.SESSION_CONFIG -> "ناموفق بودن ساخت Session"
        ErrorCategory.CAPTURE_FAILED -> "شکست در ثبت تصویر/ویدیو"
        ErrorCategory.NO_FRAMES -> "دریافت‌نشدن فریم"
        ErrorCategory.TIMEOUT -> "پاسخ ندادن (Timeout)"
        ErrorCategory.IO_FILE -> "خطای فایل"
        ErrorCategory.INVALID_OUTPUT -> "خروجی نامعتبر"
        ErrorCategory.UNSUPPORTED -> "پشتیبانی‌نشدن"
        ErrorCategory.CANCELLED -> "لغو شد"
        ErrorCategory.USER_NEGATIVE -> "کاربر نتیجه را منفی گزارش کرد"
        ErrorCategory.UNKNOWN -> "خطای نامشخص"
    }

    fun cause(c: Cause): String = when (c) {
        Cause.ACCESS -> "مشکل دسترسی به دوربین (مجوز، اشغال‌بودن یا غیرفعال‌سازی)"
        Cause.CAMERA_SERVICE -> "مشکل سرویس دوربین اندروید"
        Cause.SESSION_CREATION -> "مشکل در ساخت Capture Session"
        Cause.APP_SOFTWARE -> "خطای نرم‌افزاری یا ناسازگاری برنامه‌ی دوربین"
        Cause.IMAGE_PIPELINE -> "اختلال احتمالی در پردازش تصویر"
        Cause.CONNECTION_FLEX -> "مشکل احتمالی در اتصال یا فلت"
        Cause.CAMERA_MODULE -> "مشکل احتمالی ماژول دوربین"
        Cause.API_LIMITATION -> "محدودیت یا ناسازگاری API"
        Cause.INCONCLUSIVE -> "نتیجه نامشخص؛ نیاز به بررسی بیشتر"
    }

    fun confidence(c: Confidence): String = when (c) {
        Confidence.UNDETERMINED -> "نامشخص"
        Confidence.LOW -> "اطمینان کم"
        Confidence.MEDIUM -> "اطمینان متوسط"
        Confidence.HIGH -> "اطمینان بالا"
    }

    fun overall(o: OverallStatus): String = when (o) {
        OverallStatus.NO_DATA -> "داده‌ی کافی وجود ندارد"
        OverallStatus.ISSUES_FOUND -> "در آزمایش‌ها خطا دیده شد"
        OverallStatus.PARTIAL -> "نتیجه ناقص یا نامشخص"
        OverallStatus.PASSED_TESTED_PATHS -> "مسیرهای آزمایش‌شده خطایی نداشتند (سلامت کامل تأیید نمی‌شود)"
    }

    fun repair(r: RepairAdvice): String = when (r) {
        RepairAdvice.RECOMMENDED -> "مراجعه به تعمیرکار توصیه می‌شود"
        RepairAdvice.CONSIDER -> "ابتدا مراحل نرم‌افزاری را امتحان کنید؛ در صورت تداوم، مراجعه به تعمیرکار را در نظر بگیرید"
        RepairAdvice.NOT_INDICATED_YET -> "فعلاً شواهد کافی برای مراجعه‌ی فوری وجود ندارد"
        RepairAdvice.UNDETERMINED -> "با داده‌ی فعلی نمی‌توان درباره‌ی تعمیر نظر داد"
    }

    fun mode(m: RunMode): String = if (m == RunMode.FULL) "آزمایش کامل" else "آزمایش سریع"

    fun camera(id: String, f: LensFacing?): String =
        if (f == null) "دوربین $id" else "دوربین $id (${facing(f)})"
}
