package com.cameradiag.lab.data

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import com.cameradiag.lab.core.DeviceInfo

object DeviceInfoReader {
    fun read(ctx: Context): DeviceInfo {
        val pm = ctx.packageManager
        val apps = try {
            val pkgs = LinkedHashSet<String>()
            for (action in listOf(MediaStore.ACTION_IMAGE_CAPTURE, MediaStore.ACTION_VIDEO_CAPTURE)) {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(Intent(action), 0).forEach { pkgs.add(it.activityInfo.packageName) }
            }
            pkgs.map { pkg ->
                val v = try {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, 0).versionName
                } catch (e: Exception) {
                    null
                }
                if (v != null) "$pkg ($v)" else pkg
            }
        } catch (e: Exception) {
            emptyList()
        }
        return DeviceInfo(
            manufacturer = Build.MANUFACTURER ?: "",
            model = Build.MODEL ?: "",
            androidRelease = Build.VERSION.RELEASE ?: "",
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH,
            stockCameraApps = apps
        )
    }
}
