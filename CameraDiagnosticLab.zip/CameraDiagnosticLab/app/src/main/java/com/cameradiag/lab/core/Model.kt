package com.cameradiag.lab.core

enum class TestStatus { PASSED, FAILED, WARNING, NOT_TESTED, UNSUPPORTED, INCONCLUSIVE }

enum class TestKind { OPEN, PREVIEW, PHOTO, VIDEO, FLASH, SWITCH }

enum class LensFacing { BACK, FRONT, EXTERNAL, UNKNOWN }

enum class RunMode { FULL, QUICK }

enum class UserAnswer { YES, NO, UNKNOWN }

enum class ErrorCategory {
    PERMISSION, SECURITY, IN_USE, DISABLED, DISCONNECTED, DEVICE_ERROR, SERVICE_ERROR,
    SESSION_CONFIG, CAPTURE_FAILED, NO_FRAMES, TIMEOUT, IO_FILE, INVALID_OUTPUT,
    UNSUPPORTED, CANCELLED, USER_NEGATIVE, UNKNOWN
}

enum class Cause {
    ACCESS, CAMERA_SERVICE, SESSION_CREATION, APP_SOFTWARE, IMAGE_PIPELINE,
    CONNECTION_FLEX, CAMERA_MODULE, API_LIMITATION, INCONCLUSIVE
}

enum class Confidence { UNDETERMINED, LOW, MEDIUM, HIGH }

enum class RepairAdvice { RECOMMENDED, CONSIDER, NOT_INDICATED_YET, UNDETERMINED }

enum class OverallStatus { NO_DATA, ISSUES_FOUND, PARTIAL, PASSED_TESTED_PATHS }

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String?,
    val stockCameraApps: List<String>
)

data class CameraInfo(
    val id: String,
    val lensFacing: LensFacing,
    val flashAvailable: Boolean,
    val hardwareLevel: String,
    val capabilities: List<String>,
    val sensorOrientation: Int?,
    val maxJpegSize: String?,
    val physicalCameraIds: List<String>,
    val note: String? = null
)

data class TestResult(
    val kind: TestKind,
    val cameraId: String,
    val status: TestStatus,
    val stage: String? = null,
    val durationMs: Long? = null,
    val category: ErrorCategory? = null,
    val exceptionType: String? = null,
    val message: String? = null,
    val details: Map<String, String> = emptyMap(),
    val stackTop: List<String> = emptyList(),
    val timestampMillis: Long = 0L,
    val userConfirmed: Boolean = false
) {
    val executed: Boolean get() = status == TestStatus.PASSED || status == TestStatus.FAILED || status == TestStatus.WARNING
    val manual: Boolean get() = details["manual"] == "true"
}

object UserQuestions {
    const val STOCK_OPENS = "stock_opens"
    const val REAR_BLACK = "rear_black"
    const val CRASH_ON_SWITCH = "crash_on_switch"
    const val PHOTO_BROKEN_VIDEO_OK = "photo_broken_video_ok"
    const val FRONT_OK = "front_ok"
    const val FLASH_OK = "flash_ok"
    const val AFTER_REPAIR = "after_repair"
    const val CLEAR_DATA_CHANGED = "clear_data_changed"

    val all: List<Pair<String, String>> = listOf(
        STOCK_OPENS to "برنامه‌ی دوربین اصلی گوشی باز می‌شود؟",
        REAR_BLACK to "دوربین پشت در برنامه‌ی اصلی تصویر سیاه نشان می‌دهد؟",
        CRASH_ON_SWITCH to "هنگام عوض‌کردن دوربین، برنامه‌ی دوربین اصلی بسته می‌شود یا هنگ می‌کند؟",
        PHOTO_BROKEN_VIDEO_OK to "عکاسی مشکل دارد ولی فیلم‌برداری درست کار می‌کند؟",
        FRONT_OK to "دوربین سلفی در برنامه‌ی اصلی درست کار می‌کند؟",
        FLASH_OK to "چراغ‌قوه‌ی گوشی درست کار می‌کند؟",
        AFTER_REPAIR to "مشکل بعد از تعمیر یا به‌روزرسانی شروع شده است؟",
        CLEAR_DATA_CHANGED to "پاک‌کردن حافظه‌ی موقت یا داده‌ی برنامه‌ی دوربین، مشکل را (حتی موقتاً) تغییر داد؟"
    )
}

data class UserReport(val answers: Map<String, UserAnswer> = emptyMap()) {
    fun answer(key: String): UserAnswer = answers[key] ?: UserAnswer.UNKNOWN
    fun isEmpty(): Boolean = answers.values.all { it == UserAnswer.UNKNOWN }
    fun reportsStockProblem(): Boolean =
        answer(UserQuestions.STOCK_OPENS) == UserAnswer.NO ||
            answer(UserQuestions.REAR_BLACK) == UserAnswer.YES ||
            answer(UserQuestions.CRASH_ON_SWITCH) == UserAnswer.YES ||
            answer(UserQuestions.PHOTO_BROKEN_VIDEO_OK) == UserAnswer.YES
}

data class Finding(
    val cause: Cause,
    val confidence: Confidence,
    val evidenceFor: List<String>,
    val evidenceAgainst: List<String>,
    val nextStep: String
)

data class Analysis(
    val overall: OverallStatus,
    val findings: List<Finding>,
    val repairAdvice: RepairAdvice,
    val repairNote: String,
    val limitations: List<String>
)

data class DiagnosticReport(
    val device: DeviceInfo,
    val timestampMillis: Long,
    val mode: RunMode,
    val completed: Boolean,
    val cameraPermissionGranted: Boolean?,
    val cameras: List<CameraInfo>,
    val cameraListError: String?,
    val results: List<TestResult>,
    val userReport: UserReport,
    val analysis: Analysis
)

data class AnalysisInput(
    val cameras: List<CameraInfo>,
    val results: List<TestResult>,
    val user: UserReport,
    val cameraPermissionGranted: Boolean?,
    val cameraListError: String?
)
