package com.cameradiag.lab.data

import android.content.Context
import com.cameradiag.lab.core.DiagnosticReport
import com.cameradiag.lab.core.ReportFormatter
import com.cameradiag.lab.core.UserAnswer
import com.cameradiag.lab.core.UserQuestions
import com.cameradiag.lab.core.UserReport
import java.io.File

data class AppSettings(val videoSeconds: Int = 3, val videoAudio: Boolean = false)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AppSettings = AppSettings(
        videoSeconds = prefs.getInt("videoSeconds", 3).coerceIn(2, 10),
        videoAudio = prefs.getBoolean("videoAudio", false)
    )

    fun save(s: AppSettings) {
        prefs.edit().putInt("videoSeconds", s.videoSeconds.coerceIn(2, 10)).putBoolean("videoAudio", s.videoAudio).apply()
    }
}

class UserReportStore(context: Context) {
    private val prefs = context.getSharedPreferences("user_report", Context.MODE_PRIVATE)

    fun load(): UserReport {
        val m = HashMap<String, UserAnswer>()
        for ((k, _) in UserQuestions.all) {
            val v = prefs.getString(k, null)
            m[k] = try { if (v == null) UserAnswer.UNKNOWN else UserAnswer.valueOf(v) } catch (e: Exception) { UserAnswer.UNKNOWN }
        }
        return UserReport(m)
    }

    fun save(r: UserReport) {
        val e = prefs.edit()
        for ((k, _) in UserQuestions.all) e.putString(k, r.answer(k).name)
        e.apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}

data class ReportEntry(val id: String, val timestampMillis: Long, val overall: String, val txt: File, val json: File)

class ReportStore(context: Context) {
    private val dir: File = File(context.filesDir, "reports").also { it.mkdirs() }
    private val nameRe = Regex("report_(\\d+)_([A-Z_]+)\\.txt")

    fun save(report: DiagnosticReport): ReportEntry {
        val id = "report_${report.timestampMillis}_${report.analysis.overall.name}"
        val txt = File(dir, "$id.txt")
        val json = File(dir, "$id.json")
        txt.writeText(ReportFormatter.toText(report), Charsets.UTF_8)
        json.writeText(ReportFormatter.toJson(report), Charsets.UTF_8)
        return ReportEntry(id, report.timestampMillis, report.analysis.overall.name, txt, json)
    }

    fun list(): List<ReportEntry> =
        (dir.listFiles() ?: emptyArray()).mapNotNull { f ->
            val m = nameRe.matchEntire(f.name) ?: return@mapNotNull null
            val id = "report_${m.groupValues[1]}_${m.groupValues[2]}"
            ReportEntry(id, m.groupValues[1].toLongOrNull() ?: 0L, m.groupValues[2], f, File(dir, "$id.json"))
        }.sortedByDescending { it.timestampMillis }

    fun readText(e: ReportEntry): String = try { e.txt.readText(Charsets.UTF_8) } catch (ex: Exception) { "" }

    fun delete(e: ReportEntry) {
        try { e.txt.delete() } catch (ex: Exception) { }
        try { e.json.delete() } catch (ex: Exception) { }
    }

    fun deleteAll() {
        (dir.listFiles() ?: emptyArray()).forEach { try { it.delete() } catch (ex: Exception) { } }
    }
}
