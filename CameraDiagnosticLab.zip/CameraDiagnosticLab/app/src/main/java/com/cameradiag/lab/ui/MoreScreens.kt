package com.cameradiag.lab.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.cameradiag.lab.MainViewModel
import com.cameradiag.lab.Screen
import com.cameradiag.lab.UiState
import com.cameradiag.lab.UserPrompt
import com.cameradiag.lab.core.Fa
import com.cameradiag.lab.core.Labels
import com.cameradiag.lab.core.OverallStatus
import com.cameradiag.lab.core.ReportFormatter
import com.cameradiag.lab.core.UserAnswer
import com.cameradiag.lab.core.UserQuestions
import com.cameradiag.lab.core.UserReport
import com.cameradiag.lab.data.AppSettings
import com.cameradiag.lab.data.SampleFile
import java.io.File

private val pad = PaddingValues(16.dp)

@Composable
fun HistoryScreen(vm: MainViewModel, s: UiState) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("گزارش‌ها و تاریخچه") { vm.back() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (s.history.isEmpty()) {
                item { AppCard { Body("گزارشی ذخیره نشده است. هر آزمایش به‌صورت خودکار و فقط در حافظه‌ی خصوصی همین برنامه ذخیره می‌شود.") } }
            }
            items(s.history) { e ->
                val o = OverallStatus.values().firstOrNull { it.name == e.overall }
                AppCard(Modifier.clickable { vm.openReport(e) }) {
                    Text(Fa.dateTime(e.timestampMillis), fontSize = 15.sp)
                    if (o != null) Muted(Labels.overall(o))
                    Muted("برای دیدن جزئیات، لمس کنید")
                }
            }
            if (s.history.isNotEmpty()) {
                item { SecondaryButton("حذف همه‌ی گزارش‌ها") { vm.deleteAllReports() } }
            }
        }
    }
}

@Composable
fun ReportViewScreen(vm: MainViewModel, s: UiState) {
    val e = s.viewingEntry
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("جزئیات گزارش") { vm.back() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (e != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("اشتراک‌گذاری", Modifier.weight(1f)) { vm.requestShare(e) }
                    SecondaryButton("حذف", Modifier.weight(1f)) { vm.deleteReport(e) }
                }
            }
            SelectionContainer {
                Text(s.viewingText.ifBlank { "گزارش خوانده نشد." }, fontSize = 13.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
fun GuideScreen(vm: MainViewModel, s: UiState, launch: (Intent) -> Unit) {
    val pkgs = s.device.stockCameraApps.map { it.substringBefore(' ') }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("راهنمای رفع مشکل") { vm.back() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AppCard {
                    SectionTitle("ترتیب پیشنهادی بررسی")
                    Body("۱. آزمایش کامل را اجرا کنید و «گزارش دستی خرابی» را پر کنید.")
                    Body("۲. گوشی را کامل خاموش و روشن کنید و دوباره آزمایش کنید.")
                    Body("۳. به‌روزرسانی‌های سیستم و برنامه‌ی دوربین را بررسی کنید.")
                    Body("۴. گوشی را در Safe Mode بالا بیاورید (دکمه‌ی خاموش را نگه دارید و روی «خاموش» بزنید تا گزینه‌ی Safe Mode بیاید) و برنامه‌ی دوربین را امتحان کنید؛ اگر آنجا درست بود، یک برنامه‌ی شخص ثالث دخیل است.")
                    Body("۵. اگر پس از تعویض نمایشگر یا تعمیر شروع شده و دوربین پشت در آزمایش‌های این برنامه هم فریم نداد یا باز نشد، از تعمیرکار بخواهید اتصال و فلت دوربین را بازبینی کند.")
                }
            }
            item {
                AppCard {
                    SectionTitle("معنای نتیجه‌ها")
                    Body("اگر Camera2 در این برنامه درست کار کند ولی برنامه‌ی دوربین اصلی خراب باشد، فقط می‌توان گفت این مسیر آزمایش‌شده کار کرده است؛ سلامت کامل دوربین کارخانه‌ای ثابت نمی‌شود.")
                    Body("اگر دوربین پشت باز می‌شود ولی هیچ فریمی نمی‌رسد، یا همیشه سیاه است، احتمال مشکل ماژول/اتصال بیشتر می‌شود؛ ولی نرم‌افزار نمی‌تواند خرابی فیزیکی را قطعی کند.")
                }
            }
            item {
                AppCard {
                    SectionTitle("تهیه‌ی Bug Report رسمی اندروید")
                    Body("برای خطاهای عمیق سیستمی، پس از تکرار مشکل، Bug Report رسمی بگیرید: تنظیمات ← درباره‌ی گوشی ← شماره‌ی ساخت را ۷ بار لمس کنید تا گزینه‌های توسعه‌دهنده فعال شود ← گزینه‌های توسعه‌دهنده ← «Take bug report» (در بعضی گوشی‌ها «Capture bug report»).")
                    Muted("این برنامه فایل Bug Report را تحلیل نمی‌کند و چیزی از آن نمی‌خواند؛ آن را فقط خودتان و هر جا که خواستید به تعمیرکار بدهید. محتوای آن می‌تواند حساس باشد.")
                    SecondaryButton("باز کردن گزینه‌های توسعه‌دهنده") {
                        launch(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                    }
                }
            }
            if (pkgs.isNotEmpty()) {
                item {
                    AppCard {
                        SectionTitle("برنامه‌ی دوربین اصلی")
                        Muted("با این دکمه صفحه‌ی اطلاعات برنامه باز می‌شود؛ پاک‌کردن حافظه‌ی موقت یا داده را خودتان از همان‌جا انجام دهید (این برنامه چیزی پاک نمی‌کند). پاک‌کردن داده، تنظیمات دوربین را بازنشانی می‌کند.")
                        pkgs.forEach { pkg ->
                            SecondaryButton("اطلاعات برنامه: $pkg") {
                                launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, s: UiState) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("تنظیمات و حریم خصوصی") { vm.back() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AppCard {
                    SectionTitle("آزمایش فیلم‌برداری")
                    Body("مدت فیلم آزمایشی: ${Fa.digits(s.settings.videoSeconds.toString())} ثانیه")
                    Slider(
                        value = s.settings.videoSeconds.toFloat(), valueRange = 2f..10f, steps = 7,
                        onValueChange = { v -> vm.saveSettings(s.settings.copy(videoSeconds = v.toInt())) }
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("ضبط همراه با صدا", modifier = Modifier.weight(1f))
                        Switch(checked = s.settings.videoAudio, onCheckedChange = { vm.saveSettings(s.settings.copy(videoAudio = it)) })
                    }
                    Muted("پیش‌فرض بدون صداست. فقط اگر این گزینه روشن باشد، هنگام آزمایش فیلم مجوز میکروفون پرسیده می‌شود.")
                }
            }
            item {
                AppCard {
                    SectionTitle("حریم خصوصی")
                    Body("• برنامه کاملاً آفلاین است؛ حساب کاربری، ورود Google، تحلیل ابری یا ارسال خودکار داده وجود ندارد.")
                    Body("• گزارش‌ها، عکس و فیلم آزمایشی فقط در حافظه‌ی خصوصی برنامه می‌مانند و به گالری یا اینترنت منتقل نمی‌شوند.")
                    Body("• مجوز دوربین فقط هنگام آزمایش و مجوز میکروفون فقط هنگام ضبط ویدیو با صدا خواسته می‌شود. مکان، مخاطبین و پیام‌ها استفاده نمی‌شوند.")
                    Body("• برنامه هیچ داده یا تنظیمی از گوشی را پاک یا تغییر نمی‌دهد و به Root نیاز ندارد.")
                    Muted(ReportFormatter.CONTENT_DESCRIPTION)
                }
            }
            item { SecondaryButton("عکس‌ها و فیلم‌های آزمایشی") { vm.navigate(Screen.SAMPLES) } }
            item { SecondaryButton("حذف همه‌ی گزارش‌ها") { vm.deleteAllReports() } }
            item { SecondaryButton("حذف همه‌ی فایل‌های آزمایشی") { vm.deleteAllSamples() } }
            item { Muted("نسخه‌ی برنامه: ${Fa.digits("1.0.0")}") }
        }
    }
}

@Composable
fun SamplesScreen(vm: MainViewModel, s: UiState) {
    var playing by remember { mutableStateOf<File?>(null) }
    var viewing by remember { mutableStateOf<File?>(null) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("عکس‌ها و فیلم‌های آزمایشی") { vm.back() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (s.samples.isEmpty()) item { AppCard { Body("فایل آزمایشی‌ای وجود ندارد.") } }
            items(s.samples) { f -> SampleRow(f, onOpen = { if (f.isVideo) playing = f.file else viewing = f.file }, onDelete = { vm.deleteSample(f) }) }
            if (s.samples.isNotEmpty()) item { SecondaryButton("حذف همه") { vm.deleteAllSamples() } }
        }
    }
    playing?.let { f ->
        Dialog(onDismissRequest = { playing = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AndroidView(
                        factory = { c ->
                            VideoView(c).apply {
                                setVideoPath(f.absolutePath)
                                setOnPreparedListener { it.isLooping = true; start() }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(320.dp)
                    )
                    SecondaryButton("بستن") { playing = null }
                }
            }
        }
    }
    viewing?.let { f ->
        Dialog(onDismissRequest = { viewing = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val bmp = remember(f) { BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap() }
                    if (bmp != null) Image(bmp, contentDescription = "عکس آزمایشی", modifier = Modifier.fillMaxWidth().height(380.dp), contentScale = ContentScale.Fit)
                    else Body("عکس قابل‌نمایش نیست.")
                    SecondaryButton("بستن") { viewing = null }
                }
            }
        }
    }
}

@Composable
private fun SampleRow(f: SampleFile, onOpen: () -> Unit, onDelete: () -> Unit) {
    AppCard {
        if (!f.isVideo) {
            val bmp = remember(f.file) { BitmapFactory.decodeFile(f.file.absolutePath, BitmapFactory.Options().apply { inSampleSize = 8 })?.asImageBitmap() }
            if (bmp != null) Image(bmp, contentDescription = "بندانگشتی عکس", modifier = Modifier.fillMaxWidth().height(140.dp), contentScale = ContentScale.Crop)
        }
        Text(f.file.name, fontSize = 13.sp)
        Muted("${if (f.isVideo) "ویدیو" else "عکس"} · ${Fa.digits((f.sizeBytes / 1024).toString())} کیلوبایت · ${Fa.dateTime(f.modified)}")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryButton(if (f.isVideo) "پخش" else "مشاهده", Modifier.weight(1f)) { onOpen() }
            SecondaryButton("حذف", Modifier.weight(1f)) { onDelete() }
        }
    }
}

@Composable
fun UserReportScreen(vm: MainViewModel, s: UiState) {
    var answers by remember { mutableStateOf(s.userReport.answers) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("گزارش دستی خرابی") { vm.back() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                AppCard {
                    Body("درباره‌ی رفتار برنامه‌ی دوربین اصلی گوشی پاسخ دهید. این پاسخ‌ها «گزارش کاربر» حساب می‌شوند، نه داده‌ی اندازه‌گیری‌شده از سیستم، و فقط به‌عنوان شاهد کمکی در تحلیل به کار می‌روند.")
                }
            }
            items(UserQuestions.all) { (key, q) ->
                AppCard {
                    Body(q)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(UserAnswer.YES to "بله", UserAnswer.NO to "خیر", UserAnswer.UNKNOWN to "نمی‌دانم").forEach { (a, label) ->
                            val selected = (answers[key] ?: UserAnswer.UNKNOWN) == a
                            if (selected) {
                                Button(onClick = { answers = answers + (key to a) }, modifier = Modifier.weight(1f)) { Text(label) }
                            } else {
                                OutlinedButton(onClick = { answers = answers + (key to a) }, modifier = Modifier.weight(1f)) { Text(label) }
                            }
                        }
                    }
                }
            }
            item { PrimaryButton("ذخیره") { vm.saveUserReport(UserReport(answers)) } }
            item { SecondaryButton("بازگشت") { vm.back() } }
        }
    }
}

@Composable
fun PromptDialog(p: UserPrompt, onAnswer: (UserAnswer) -> Unit) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("تأیید شما لازم است") },
        text = { Text(p.text) },
        confirmButton = {
            Row {
                TextButton(onClick = { onAnswer(UserAnswer.YES) }) { Text("بله") }
                TextButton(onClick = { onAnswer(UserAnswer.NO) }) { Text("خیر") }
                TextButton(onClick = { onAnswer(UserAnswer.UNKNOWN) }) { Text("نمی‌دانم") }
            }
        }
    )
}

@Composable
fun ShareDialog(vm: MainViewModel, launch: (Intent) -> Unit) {
    AlertDialog(
        onDismissRequest = { vm.dismissShare() },
        title = { Text("پیش از اشتراک‌گذاری") },
        text = { Text(ReportFormatter.CONTENT_DESCRIPTION) },
        confirmButton = {
            Row {
                TextButton(onClick = { vm.share(true)?.let(launch) }) { Text("فایل JSON") }
                TextButton(onClick = { vm.share(false)?.let(launch) }) { Text("فایل متنی") }
            }
        },
        dismissButton = { TextButton(onClick = { vm.dismissShare() }) { Text("انصراف") } }
    )
}

@Composable
fun DiagApp(vm: MainViewModel, launch: (Intent) -> Unit) {
    DiagTheme {
        val s by vm.ui.collectAsState()
        val ctx = LocalContext.current
        BackHandler(enabled = s.screen != Screen.HOME) { vm.back() }
        val safeLaunch: (Intent) -> Unit = { i ->
            try {
                launch(i)
            } catch (e: Exception) {
                Toast.makeText(ctx, "این بخش در گوشی شما در دسترس نیست.", Toast.LENGTH_SHORT).show()
            }
        }
        Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
                when (s.screen) {
                    Screen.HOME -> HomeScreen(vm, s)
                    Screen.DEVICES -> DevicesScreen(vm, s)
                    Screen.AUTO -> AutoScreen(vm, s)
                    Screen.MANUAL -> ManualScreen(vm, s)
                    Screen.RESULTS -> ResultsScreen(vm, s)
                    Screen.HISTORY -> HistoryScreen(vm, s)
                    Screen.GUIDE -> GuideScreen(vm, s, safeLaunch)
                    Screen.SETTINGS -> SettingsScreen(vm, s)
                    Screen.USER_REPORT -> UserReportScreen(vm, s)
                    Screen.SAMPLES -> SamplesScreen(vm, s)
                    Screen.REPORT_VIEW -> ReportViewScreen(vm, s)
                }
            }
        }
        s.prompt?.let { p -> PromptDialog(p) { vm.answerPrompt(it) } }
        if (s.shareTarget != null) ShareDialog(vm, safeLaunch)
        LaunchedEffect(s.toast) {
            val t = s.toast
            if (t != null) {
                Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()
                vm.consumeToast()
            }
        }
    }
}
