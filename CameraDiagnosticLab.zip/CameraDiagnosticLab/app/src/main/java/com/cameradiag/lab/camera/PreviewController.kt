package com.cameradiag.lab.camera

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.util.Size
import android.view.Surface
import com.cameradiag.lab.core.CameraFailure
import com.cameradiag.lab.core.ErrorCategory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed class PreviewEvent {
    data class Status(val text: String) : PreviewEvent()
    object Running : PreviewEvent()
    data class Error(val category: ErrorCategory, val message: String) : PreviewEvent()
}

/** Live on-screen preview for the manual test page. stop() always releases session, camera, surface and thread. */
class PreviewController(private val context: Context) {
    private val mgr = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var closer: Closer? = null
    private var thread: CameraThread? = null

    /** width/height ratio the on-screen view should have (portrait phones: sensor is rotated). */
    fun aspectRatio(id: String): Float {
        return try {
            val ch = mgr.getCameraCharacteristics(id)
            val size = chooseSize(ch) ?: return 3f / 4f
            val ori = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            if (ori == 90 || ori == 270) size.height.toFloat() / size.width else size.width.toFloat() / size.height
        } catch (e: Exception) {
            3f / 4f
        }
    }

    private fun chooseSize(ch: CameraCharacteristics): Size? {
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        return pickClosest(map?.getOutputSizes(SurfaceTexture::class.java), 1280, 720, 1920L * 1080)
    }

    fun start(id: String, texture: SurfaceTexture, onEvent: (PreviewEvent) -> Unit) {
        stop()
        val c = Closer()
        val th = CameraThread("diag-preview")
        closer = c
        thread = th
        job = scope.launch {
            try {
                onEvent(PreviewEvent.Status("در حال باز کردن دوربین $id…"))
                delay(250)
                val ch = mgr.getCameraCharacteristics(id)
                val size = chooseSize(ch)
                    ?: throw CameraFailure(ErrorCategory.UNSUPPORTED, "اندازه‌ی خروجی پیش‌نمایش گزارش نشد.", "getCharacteristics")
                texture.setDefaultBufferSize(size.width, size.height)
                val surface = Surface(texture)
                c.add { surface.release() }
                val cam = openManaged(mgr, id, th, c)
                onEvent(PreviewEvent.Status("ساخت Session…"))
                val session = createSession(cam, listOf(surface), th, c)
                c.add { session.stopRepeating() }
                val b = cam.device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                b.addTarget(surface)
                applyAuto(b, ch)
                session.setRepeatingRequest(b.build(), null, th.handler)
                onEvent(PreviewEvent.Running)
                cam.newWaiter<Unit>().await() // suspends until the camera fails or the job is cancelled
            } catch (e: CancellationException) {
                throw e
            } catch (e: CameraFailure) {
                onEvent(PreviewEvent.Error(e.category, e.message ?: "خطا"))
            } catch (e: CameraAccessException) {
                val f = mapAccess(e, "preview")
                onEvent(PreviewEvent.Error(f.category, f.message ?: "خطا"))
            } catch (e: Exception) {
                onEvent(PreviewEvent.Error(ErrorCategory.UNKNOWN, "${e.javaClass.simpleName}: ${e.message}"))
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        closer?.closeAll()
        closer = null
        thread?.close()
        thread = null
    }
}
