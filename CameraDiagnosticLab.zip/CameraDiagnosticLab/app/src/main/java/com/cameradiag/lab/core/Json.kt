package com.cameradiag.lab.core

/** Tiny dependency-free JSON writer (works in plain JVM unit tests). */
object Json {
    fun stringify(value: Any?): String {
        val sb = StringBuilder()
        write(sb, value, 0)
        return sb.toString()
    }

    private fun indent(sb: StringBuilder, depth: Int) {
        sb.append('\n')
        for (i in 0 until depth) sb.append("  ")
    }

    private fun write(sb: StringBuilder, v: Any?, depth: Int) {
        when (v) {
            null -> sb.append("null")
            is String -> quote(sb, v)
            is Boolean -> sb.append(v.toString())
            is Int -> sb.append(v.toString())
            is Long -> sb.append(v.toString())
            is Double -> sb.append(if (v.isNaN() || v.isInfinite()) "null" else v.toString())
            is Enum<*> -> quote(sb, v.name)
            is Map<*, *> -> {
                if (v.isEmpty()) {
                    sb.append("{}")
                } else {
                    sb.append('{')
                    var first = true
                    for ((k, value) in v) {
                        if (!first) sb.append(',')
                        first = false
                        indent(sb, depth + 1)
                        quote(sb, k.toString())
                        sb.append(": ")
                        write(sb, value, depth + 1)
                    }
                    indent(sb, depth)
                    sb.append('}')
                }
            }
            is Iterable<*> -> {
                val list = v.toList()
                if (list.isEmpty()) {
                    sb.append("[]")
                } else {
                    sb.append('[')
                    var first = true
                    for (item in list) {
                        if (!first) sb.append(',')
                        first = false
                        indent(sb, depth + 1)
                        write(sb, item, depth + 1)
                    }
                    indent(sb, depth)
                    sb.append(']')
                }
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        sb.append('"')
    }
}
