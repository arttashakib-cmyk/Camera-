package com.cameradiag.lab.data

import android.content.Context
import java.io.File

data class SampleFile(val file: File, val isVideo: Boolean, val sizeBytes: Long, val modified: Long)

/** Test photos/videos live only in the app's private storage. */
class SampleStore(context: Context) {
    private val dir: File = File(context.filesDir, "samples").also { it.mkdirs() }

    fun newFile(prefix: String, ext: String): File {
        val safe = prefix.replace(Regex("[^A-Za-z0-9_]"), "_")
        return File(dir, "${safe}_${System.currentTimeMillis()}.$ext")
    }

    fun list(): List<SampleFile> =
        (dir.listFiles() ?: emptyArray()).filter { it.isFile }
            .map { SampleFile(it, it.extension.lowercase() == "mp4", it.length(), it.lastModified()) }
            .sortedByDescending { it.modified }

    fun delete(f: File): Boolean = try { f.delete() } catch (e: Exception) { false }

    fun deleteAll() {
        (dir.listFiles() ?: emptyArray()).forEach { try { it.delete() } catch (e: Exception) { } }
    }
}
