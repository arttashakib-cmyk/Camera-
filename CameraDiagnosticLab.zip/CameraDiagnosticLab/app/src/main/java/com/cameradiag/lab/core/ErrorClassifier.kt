package com.cameradiag.lab.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException

/** Failure raised by the camera layer with an already-classified category. */
class CameraFailure(
    val category: ErrorCategory,
    message: String,
    val stage: String? = null,
    cause: Throwable? = null
) : Exception(message, cause)

object ErrorClassifier {
    /** CameraAccessException.getReason() values. */
    fun fromAccessReason(reason: Int): ErrorCategory = when (reason) {
        1 -> ErrorCategory.DISABLED        // CAMERA_DISABLED
        2 -> ErrorCategory.DISCONNECTED    // CAMERA_DISCONNECTED
        3 -> ErrorCategory.DEVICE_ERROR    // CAMERA_ERROR
        4 -> ErrorCategory.IN_USE          // CAMERA_IN_USE
        5 -> ErrorCategory.IN_USE          // MAX_CAMERAS_IN_USE
        else -> ErrorCategory.UNKNOWN
    }

    /** CameraDevice.StateCallback.onError() codes. */
    fun fromDeviceStateError(code: Int): ErrorCategory = when (code) {
        1 -> ErrorCategory.IN_USE          // ERROR_CAMERA_IN_USE
        2 -> ErrorCategory.IN_USE          // ERROR_MAX_CAMERAS_IN_USE
        3 -> ErrorCategory.DISABLED        // ERROR_CAMERA_DISABLED
        4 -> ErrorCategory.DEVICE_ERROR    // ERROR_CAMERA_DEVICE
        5 -> ErrorCategory.SERVICE_ERROR   // ERROR_CAMERA_SERVICE
        else -> ErrorCategory.UNKNOWN
    }

    fun fromThrowable(t: Throwable): ErrorCategory = when (t) {
        is CameraFailure -> t.category
        is TimeoutCancellationException -> ErrorCategory.TIMEOUT
        is CancellationException -> ErrorCategory.CANCELLED
        is SecurityException -> ErrorCategory.SECURITY
        is java.io.IOException -> ErrorCategory.IO_FILE
        else -> ErrorCategory.UNKNOWN
    }

    fun stackTop(t: Throwable, max: Int = 8): List<String> =
        t.stackTrace.take(max).map { "${it.className}.${it.methodName}:${it.lineNumber}" }
}
