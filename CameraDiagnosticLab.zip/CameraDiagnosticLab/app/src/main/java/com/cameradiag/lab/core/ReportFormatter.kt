package com.cameradiag.lab.core

object ReportFormatter {

    const val SCHEMA_VERSION = 1

    /** Short Persian description of what a shared report contains (shown before sharing). */
    val CONTENT_DESCRIPTION: String =
        "این گزارش شامل موارد زیر است: مدل دستگاه و نسخه‌ی اندروید، فهرست و مشخصات فنی دوربین‌ها، نتیجه و زمان هر آزمایش، " +
            "پیام و نوع خطاهای ثبت‌شده (با حذف مسیرها، ایمیل، آدرس شبکه و شماره‌های بلند)، پاسخ‌های «گزارش کاربر» و تحلیل. " +
            "شناسه‌ی گوشی، شماره‌ی سریال، مکان، مخاطبین، عکس و فیلم آزمایشی در گزارش نیست. " +
            "گزارش فقط وقتی ارسال می‌شود که خودتان در پنجره‌ی اشتراک‌گذاری مقصد را انتخاب کنید."

    private fun answerFa(a: UserAnswer) = when (a) {
        UserAnswer.YES -> "بله"
        UserAnswer.NO -> "خیر"
        UserAnswer.UNKNOWN -> "نمی‌دانم"
    }

    private fun resultLine(r: TestResult, facing: Map<String, LensFacing>): String {
        val sb = StringBuilder()
        sb.append("• ").append(Labels.kind(r.kind)).append(" — ")
        sb.append(Labels.camera(r.cameraId, facing[r.cameraId])).append(": ").append(Labels.status(r.status))
        if (r.manual) sb.append(" [آزمایش دستی]")
        if (r.userConfirmed) sb.append(" [تأیید کاربر]")
        if (r.durationMs != null) sb.append(" | زمان: ").append(Fa.ms(r.durationMs))
        if (r.stage != null && r.status != TestStatus.PASSED) sb.append(" | مرحله: ").append(r.stage)
        if (r.category != null) sb.append(" | نوع: ").append(Labels.category(r.category))
        if (!r.message.isNullOrBlank()) sb.append("\n    ").append(Sanitizer.redact(r.message))
        return sb.toString()
    }

    fun toText(report: DiagnosticReport): String {
        val facing = report.cameras.associate { it.id to it.lensFacing }
        val sb = StringBuilder()
        fun line(s: String = "") { sb.append(s).append('\n') }

        line("گزارش آزمایشگاه عیب‌یابی دوربین")
        line("======================================")
        line("تاریخ و زمان: ${Fa.dateTime(report.timestampMillis)}  (${Fa.isoUtc(report.timestampMillis)})")
        line("دستگاه: ${report.device.manufacturer} ${report.device.model}")
        line("نسخه‌ی اندروید: ${report.device.androidRelease} (API ${report.device.sdkInt})" +
            (report.device.securityPatch?.let { " — وصله‌ی امنیتی $it" } ?: ""))
        if (report.device.stockCameraApps.isNotEmpty()) line("برنامه‌ی دوربین اصلی: ${report.device.stockCameraApps.joinToString("، ")}")
        line("حالت آزمایش: ${Labels.mode(report.mode)}" + if (report.completed) "" else " (ناتمام/لغوشده)")
        line("مجوز دوربین: " + when (report.cameraPermissionGranted) { true -> "داده شده"; false -> "داده نشده"; null -> "نامشخص" })
        line()
        line("وضعیت کلی: ${Labels.overall(report.analysis.overall)}")
        line("توجه: این گزارش هرگز «سلامت قطعی» اعلام نمی‌کند؛ فقط آزمایش‌هایی که واقعاً اجرا شده‌اند ارزیابی می‌شوند.")
        line()

        line("فهرست دوربین‌ها")
        line("--------------------------------------")
        if (report.cameras.isEmpty()) {
            line("هیچ دوربینی از Camera2 گزارش نشد." + (report.cameraListError?.let { " خطا: ${Sanitizer.redact(it)}" } ?: ""))
        }
        report.cameras.forEach { c ->
            line("• دوربین ${c.id} — ${Labels.facing(c.lensFacing)} | سطح سخت‌افزار: ${c.hardwareLevel} | فلش: ${if (c.flashAvailable) "دارد" else "ندارد"}")
            line("    جهت حسگر: ${c.sensorOrientation ?: "نامشخص"} | بزرگ‌ترین JPEG: ${c.maxJpegSize ?: "نامشخص"}")
            if (c.capabilities.isNotEmpty()) line("    قابلیت‌ها: ${c.capabilities.joinToString(", ")}")
            if (c.physicalCameraIds.isNotEmpty()) line("    دوربین‌های فیزیکی زیرمجموعه: ${c.physicalCameraIds.joinToString(", ")}")
            if (c.note != null) line("    توضیح: ${Sanitizer.redact(c.note)}")
        }
        line()

        val passed = report.results.filter { it.status == TestStatus.PASSED }
        val failedR = report.results.filter { it.status == TestStatus.FAILED }
        val unsure = report.results.filter { it.status != TestStatus.PASSED && it.status != TestStatus.FAILED }

        line("آزمایش انجام شد و موفق بود")
        line("--------------------------------------")
        if (passed.isEmpty()) line("(موردی نیست)") else passed.forEach { line(resultLine(it, facing)) }
        line()
        line("آزمایش انجام شد و شکست خورد")
        line("--------------------------------------")
        if (failedR.isEmpty()) line("(موردی نیست)") else failedR.forEach { line(resultLine(it, facing)) }
        line()
        line("آزمایش انجام نشد یا نتیجه قطعی نیست")
        line("--------------------------------------")
        if (unsure.isEmpty()) line("(موردی نیست)") else unsure.forEach { line(resultLine(it, facing)) }
        line()

        line("خطاهای ثبت‌شده")
        line("--------------------------------------")
        val errs = report.results.filter { it.exceptionType != null || (it.status == TestStatus.FAILED && it.message != null) }
        if (errs.isEmpty()) line("(خطای ثبت‌شده‌ای نیست)")
        errs.forEach { r ->
            line("• ${Fa.dateTime(r.timestampMillis)} | ${Labels.kind(r.kind)} | دوربین ${r.cameraId} | مرحله: ${r.stage ?: "—"}")
            line("    Exception: ${r.exceptionType ?: "—"} | پیام: ${Sanitizer.redact(r.message) ?: "—"}")
            if (r.stackTop.isNotEmpty()) line("    Stack (محدود): " + r.stackTop.take(4).joinToString(" ← "))
        }
        line()

        line("گزارش کاربر (اندازه‌گیری مستقیم نیست)")
        line("--------------------------------------")
        if (report.userReport.isEmpty()) line("(گزارشی ثبت نشده)")
        else UserQuestions.all.forEach { (k, q) -> line("• $q → ${answerFa(report.userReport.answer(k))}") }
        line()

        line("علت‌های احتمالی")
        line("--------------------------------------")
        report.analysis.findings.forEach { f ->
            line("▪ ${Labels.cause(f.cause)} — ${Labels.confidence(f.confidence)}")
            f.evidenceFor.forEach { line("    شاهد مؤید: $it") }
            f.evidenceAgainst.forEach { line("    شاهد مخالف/محدودیت: $it") }
            line("    آزمایش یا اقدام بعدی: ${f.nextStep}")
        }
        line()
        line("پیشنهاد درباره‌ی تعمیرکار: ${Labels.repair(report.analysis.repairAdvice)}")
        line(report.analysis.repairNote)
        line()
        line("محدودیت‌های تشخیص")
        line("--------------------------------------")
        report.analysis.limitations.forEach { line("• $it") }
        return sb.toString()
    }

    private fun cameraMap(c: CameraInfo): Map<String, Any?> = linkedMapOf(
        "id" to c.id,
        "lensFacing" to c.lensFacing,
        "flashAvailable" to c.flashAvailable,
        "hardwareLevel" to c.hardwareLevel,
        "capabilities" to c.capabilities,
        "sensorOrientation" to c.sensorOrientation,
        "maxJpegSize" to c.maxJpegSize,
        "physicalCameraIds" to c.physicalCameraIds,
        "note" to Sanitizer.redact(c.note)
    )

    fun toJson(report: DiagnosticReport): String {
        val d = report.device
        val root = linkedMapOf<String, Any?>(
            "schemaVersion" to SCHEMA_VERSION,
            "app" to "Camera Diagnostic Lab",
            "timestampMillis" to report.timestampMillis,
            "timestampUtc" to Fa.isoUtc(report.timestampMillis),
            "mode" to report.mode,
            "completed" to report.completed,
            "device" to linkedMapOf(
                "manufacturer" to d.manufacturer,
                "model" to d.model,
                "androidRelease" to d.androidRelease,
                "sdkInt" to d.sdkInt,
                "securityPatch" to d.securityPatch,
                "stockCameraApps" to d.stockCameraApps
            ),
            "cameraPermissionGranted" to report.cameraPermissionGranted,
            "cameraListError" to Sanitizer.redact(report.cameraListError),
            "cameras" to report.cameras.map { cameraMap(it) },
            "results" to report.results.map { r ->
                linkedMapOf<String, Any?>(
                    "timestampMillis" to r.timestampMillis,
                    "testType" to r.kind,
                    "cameraId" to r.cameraId,
                    "stage" to r.stage,
                    "status" to r.status,
                    "durationMs" to r.durationMs,
                    "errorCategory" to r.category,
                    "exceptionType" to r.exceptionType,
                    "message" to Sanitizer.redact(r.message),
                    "stackTrace" to r.stackTop,
                    "details" to r.details,
                    "manual" to r.manual,
                    "userConfirmed" to r.userConfirmed,
                    "androidVersion" to d.androidRelease,
                    "deviceModel" to d.model
                )
            },
            "userReport" to mapOf(
                "note" to "self-reported by the user; not measured by the app",
                "answers" to report.userReport.answers.mapValues { it.value.name }
            ),
            "analysis" to linkedMapOf(
                "overall" to report.analysis.overall,
                "repairAdvice" to report.analysis.repairAdvice,
                "repairNote" to report.analysis.repairNote,
                "findings" to report.analysis.findings.map { f ->
                    linkedMapOf(
                        "cause" to f.cause,
                        "confidence" to f.confidence,
                        "evidenceFor" to f.evidenceFor,
                        "evidenceAgainst" to f.evidenceAgainst,
                        "nextStep" to f.nextStep
                    )
                },
                "limitations" to report.analysis.limitations
            )
        )
        return Json.stringify(root)
    }
}
