package com.cameradiag.lab

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cameradiag.lab.camera.CameraInspector
import com.cameradiag.lab.camera.CameraTests
import com.cameradiag.lab.camera.CameraThread
import com.cameradiag.lab.camera.PreviewController
import com.cameradiag.lab.camera.PreviewEvent
import com.cameradiag.lab.core.AnalysisInput
import com.cameradiag.lab.core.CameraInfo
import com.cameradiag.lab.core.DeviceInfo
import com.cameradiag.lab.core.DiagnosticReport
import com.cameradiag.lab.core.ErrorCategory
import com.cameradiag.lab.core.Guard
import com.cameradiag.lab.core.Labels
import com.cameradiag.lab.core.LensFacing
import com.cameradiag.lab.core.RuleEngine
import com.cameradiag.lab.core.RunMode
import com.cameradiag.lab.core.TestKind
import com.cameradiag.lab.core.TestOutcome
import com.cameradiag.lab.core.TestResult
import com.cameradiag.lab.core.TestStatus
import com.cameradiag.lab.core.UserAnswer
import com.cameradiag.lab.core.UserReport
import com.cameradiag.lab.data.AppSettings
import com.cameradiag.lab.data.DeviceInfoReader
import com.cameradiag.lab.data.ReportEntry
import com.cameradiag.lab.data.ReportStore
import com.cameradiag.lab.data.SampleFile
import com.cameradiag.lab.data.SampleStore
import com.cameradiag.lab.data.SettingsStore
import com.cameradiag.lab.data.UserReportStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

enum class Screen { HOME, DEVICES, AUTO, MANUAL, RESULTS, HISTORY, GUIDE, SETTINGS, USER_REPORT, SAMPLES, REPORT_VIEW }

class UserPrompt(val text: String, val deferred: CompletableDeferred<UserAnswer>)

data class UiState(
    val screen: Screen = Screen.HOME,
    val device: DeviceInfo,
    val cameras: List<CameraInfo> = emptyList(),
    val cameraListError: String? = null,
    val cameraPermission: Boolean = false,
    val running: Boolean = false,
    val runMode: RunMode? = null,
    val steps: List<TestResult> = emptyList(),
    val currentStep: String? = null,
    val progress: Float = 0f,
    val lastReport: DiagnosticReport? = null,
    val lastEntry: ReportEntry? = null,
    val userReport: UserReport = UserReport(),
    val settings: AppSettings = AppSettings(),
    val history: List<ReportEntry> = emptyList(),
    val samples: List<SampleFile> = emptyList(),
    val prompt: UserPrompt? = null,
    val manualResults: List<TestResult> = emptyList(),
    val previewStatus: String? = null,
    val previewRunning: Boolean = false,
    val previewError: String? = null,
    val torchOn: Boolean = false,
    val viewingEntry: ReportEntry? = null,
    val viewingText: String = "",
    val shareTarget: ReportEntry? = null,
    val toast: String? = null
)

private data class Step(val kind: TestKind, val cameraId: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application = app
    private val settingsStore = SettingsStore(ctx)
    private val userStore = UserReportStore(ctx)
    private val reportStore = ReportStore(ctx)
    private val sampleStore = SampleStore(ctx)
    private val mgr = ctx.getSystemService(android.content.Context.CAMERA_SERVICE) as CameraManager
    val preview = PreviewController(ctx)

    private val _ui = MutableStateFlow(
        UiState(
            device = DeviceInfoReader.read(ctx),
            userReport = userStore.load(),
            settings = settingsStore.load(),
            history = reportStore.list(),
            samples = sampleStore.list()
        )
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    var permissionRequester: (suspend (String) -> Boolean)? = null
    @Volatile var waitingForPermission = false
    private var runJob: Job? = null
    private var torchId: String? = null

    init {
        refreshAll()
    }

    // ---------------------------------------------------------------- navigation / refresh
    fun navigate(s: Screen) {
        if (_ui.value.screen == Screen.MANUAL && s != Screen.MANUAL) stopManual()
        _ui.update { it.copy(screen = s) }
        if (s == Screen.SAMPLES) refreshSamples()
        if (s == Screen.HISTORY) _ui.update { it.copy(history = reportStore.list()) }
    }

    fun back() {
        when (_ui.value.screen) {
            Screen.HOME -> {}
            Screen.AUTO -> {
                if (_ui.value.running) cancelRun()
                navigate(Screen.HOME)
            }
            Screen.REPORT_VIEW -> navigate(Screen.HISTORY)
            Screen.SAMPLES -> navigate(Screen.SETTINGS)
            else -> navigate(Screen.HOME)
        }
    }

    fun refreshAll() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val r = CameraInspector.inspect(ctx)
        _ui.update {
            it.copy(
                device = DeviceInfoReader.read(ctx), cameras = r.cameras, cameraListError = r.error,
                cameraPermission = granted, history = reportStore.list()
            )
        }
    }

    fun consumeToast() = _ui.update { it.copy(toast = null) }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- full / quick run
    fun startRun(mode: RunMode) {
        if (_ui.value.running) return
        stopManual()
        navigate(Screen.AUTO)
        runJob = viewModelScope.launch { runSuite(mode) }
    }

    fun cancelRun() {
        runJob?.cancel()
    }

    fun onAppBackgrounded() {
        if (_ui.value.running) cancelRun()
        if (_ui.value.screen == Screen.MANUAL) stopManual()
    }

    fun answerPrompt(a: UserAnswer) {
        _ui.value.prompt?.deferred?.complete(a)
    }

    private suspend fun askUser(text: String): UserAnswer {
        val d = CompletableDeferred<UserAnswer>()
        _ui.update { it.copy(prompt = UserPrompt(text, d)) }
        val ans = withTimeoutOrNull(60_000) { d.await() } ?: UserAnswer.UNKNOWN
        _ui.update { it.copy(prompt = null) }
        return ans
    }

    private fun timeoutFor(k: TestKind, s: AppSettings): Long = when (k) {
        TestKind.OPEN -> 10_000L
        TestKind.PREVIEW -> 20_000L
        TestKind.PHOTO -> 30_000L
        TestKind.VIDEO -> 25_000L + s.videoSeconds * 1000L
        TestKind.FLASH -> 90_000L
        TestKind.SWITCH -> 90_000L
    }

    private fun stepTitle(s: Step, cams: List<CameraInfo>): String {
        val f = cams.firstOrNull { it.id == s.cameraId }?.lensFacing
        return "${Labels.kind(s.kind)} — ${Labels.camera(s.cameraId, f)}"
    }

    private suspend fun runSuite(mode: RunMode) {
        val results = ArrayList<TestResult>()
        val settings = settingsStore.load()
        _ui.update {
            it.copy(running = true, runMode = mode, steps = emptyList(), progress = 0f, currentStep = "بررسی مجوزها", prompt = null)
        }
        var inspected = CameraInspector.inspect(ctx)
        var plan: List<Step> = emptyList()
        var camGranted: Boolean? = null
        var cancelled = false
        val nowStart = System.currentTimeMillis()

        try {
            camGranted = hasPerm(Manifest.permission.CAMERA) || (permissionRequester?.invoke(Manifest.permission.CAMERA) ?: false)
            inspected = CameraInspector.inspect(ctx)
            val cams = inspected.cameras
            val p = ArrayList<Step>()
            for (c in cams) {
                p += Step(TestKind.OPEN, c.id)
                p += Step(TestKind.PREVIEW, c.id)
                if (mode == RunMode.FULL) {
                    p += Step(TestKind.PHOTO, c.id)
                    p += Step(TestKind.VIDEO, c.id)
                    if (c.flashAvailable) p += Step(TestKind.FLASH, c.id)
                }
            }
            if (mode == RunMode.FULL) {
                val back = cams.firstOrNull { it.lensFacing == LensFacing.BACK }
                val front = cams.firstOrNull { it.lensFacing == LensFacing.FRONT }
                if (back != null && front != null) p += Step(TestKind.SWITCH, "${back.id}↔${front.id}")
                if (cams.none { it.flashAvailable } && cams.isNotEmpty()) {
                    results += TestResult(
                        TestKind.FLASH, "—", TestStatus.UNSUPPORTED, null, null, ErrorCategory.UNSUPPORTED, null,
                        "هیچ‌یک از دوربین‌ها فلش گزارش نکردند؛ این خرابی ثبت نمی‌شود.", emptyMap(), emptyList(), System.currentTimeMillis()
                    )
                }
            }
            plan = p
            publish(results, null, plan.size)

            if (camGranted != true) {
                val msg = "مجوز دوربین داده نشد. از تنظیمات گوشی ← برنامه‌ها ← آزمایشگاه عیب‌یابی دوربین ← مجوزها، دوربین را «مجاز» کنید و دوباره آزمایش کنید."
                for (s in plan) {
                    results += TestResult(s.kind, s.cameraId, TestStatus.NOT_TESTED, null, null, ErrorCategory.PERMISSION, null, msg, emptyMap(), emptyList(), System.currentTimeMillis())
                }
            } else {
                val thread = CameraThread()
                val tests = CameraTests(ctx, sampleStore)
                var audioDecided = false
                var audioGranted = false
                try {
                    for (s in plan) {
                        _ui.update { it.copy(currentStep = stepTitle(s, cams)) }
                        var audioNote: String? = null
                        if (s.kind == TestKind.VIDEO && settings.videoAudio) {
                            if (!audioDecided) {
                                audioGranted = hasPerm(Manifest.permission.RECORD_AUDIO) ||
                                    (permissionRequester?.invoke(Manifest.permission.RECORD_AUDIO) ?: false)
                                audioDecided = true
                            }
                            if (!audioGranted) audioNote = "بدون صدا؛ مجوز میکروفون داده نشد"
                        }
                        val withAudio = s.kind == TestKind.VIDEO && settings.videoAudio && audioGranted
                        val r = Guard.run(
                            s.kind, s.cameraId, timeoutFor(s.kind, settings),
                            onCancelled = { results += it }
                        ) { t ->
                            when (s.kind) {
                                TestKind.OPEN -> tests.open(s.cameraId, thread, t)
                                TestKind.PREVIEW -> tests.preview(s.cameraId, thread, t)
                                TestKind.PHOTO -> tests.photo(s.cameraId, thread, t)
                                TestKind.VIDEO -> tests.video(s.cameraId, settings.videoSeconds, withAudio, audioNote, thread, t)
                                TestKind.FLASH -> tests.flash(s.cameraId, cams.firstOrNull { it.id == s.cameraId }, thread, t) { q -> askUser(q) }
                                TestKind.SWITCH -> {
                                    val ids = s.cameraId.split("↔")
                                    tests.switchTest(ids[0], ids[1], 3, thread, t)
                                }
                            }
                        }
                        results += r
                        publish(results, null, plan.size)
                        delay(250)
                    }
                } finally {
                    thread.close()
                }
            }
        } catch (e: CancellationException) {
            cancelled = true
        } catch (e: Exception) {
            results += TestResult(
                TestKind.OPEN, "—", TestStatus.INCONCLUSIVE, "runSuite", null, ErrorCategory.UNKNOWN, e.javaClass.name,
                "اجرای آزمایش‌ها با خطای غیرمنتظره متوقف شد: ${e.message}", emptyMap(), emptyList(), System.currentTimeMillis()
            )
        }

        withContext(NonCancellable) {
            for (s in plan) {
                if (results.none { it.kind == s.kind && it.cameraId == s.cameraId }) {
                    results += TestResult(
                        s.kind, s.cameraId, TestStatus.NOT_TESTED, null, null,
                        if (cancelled) ErrorCategory.CANCELLED else null, null,
                        if (cancelled) "آزمایش قبل از اجرا لغو شد." else "این آزمایش اجرا نشد.",
                        emptyMap(), emptyList(), System.currentTimeMillis()
                    )
                }
            }
            val cams = inspected.cameras
            val all = results + _ui.value.manualResults
            val analysis = RuleEngine.analyze(AnalysisInput(cams, all, _ui.value.userReport, camGranted, inspected.error))
            val report = DiagnosticReport(
                device = DeviceInfoReader.read(ctx), timestampMillis = nowStart, mode = mode, completed = !cancelled,
                cameraPermissionGranted = camGranted, cameras = cams, cameraListError = inspected.error,
                results = all, userReport = _ui.value.userReport, analysis = analysis
            )
            val entry = try { reportStore.save(report) } catch (e: Exception) { null }
            _ui.update {
                it.copy(
                    running = false, steps = results.toList(), currentStep = null, progress = 1f, prompt = null,
                    cameras = cams, cameraListError = inspected.error, cameraPermission = camGranted == true,
                    lastReport = report, lastEntry = entry, history = reportStore.list(),
                    toast = if (entry == null) "ذخیره‌ی گزارش ناموفق بود." else null
                )
            }
        }
    }

    private fun publish(results: List<TestResult>, step: String?, total: Int) {
        _ui.update {
            it.copy(
                steps = results.toList(),
                progress = if (total <= 0) 0f else (results.size.toFloat() / total).coerceIn(0f, 1f),
                currentStep = step ?: it.currentStep
            )
        }
    }

    /** Re-run the rule engine on the last results with the latest user report and manual results. */
    fun reanalyze() {
        val last = _ui.value.lastReport ?: return
        val base = last.results.filter { !it.manual }
        val all = base + _ui.value.manualResults
        val analysis = RuleEngine.analyze(AnalysisInput(last.cameras, all, _ui.value.userReport, last.cameraPermissionGranted, last.cameraListError))
        val report = last.copy(timestampMillis = System.currentTimeMillis(), results = all, userReport = _ui.value.userReport, analysis = analysis)
        val entry = try { reportStore.save(report) } catch (e: Exception) { null }
        _ui.update { it.copy(lastReport = report, lastEntry = entry, history = reportStore.list(), toast = "تحلیل دوباره انجام و گزارش جدید ذخیره شد.") }
    }

    // ---------------------------------------------------------------- manual page
    fun previewAspect(id: String): Float = preview.aspectRatio(id)

    fun startPreview(id: String, texture: SurfaceTexture) {
        _ui.update { it.copy(previewStatus = "در حال شروع…", previewRunning = false, previewError = null) }
        preview.start(id, texture) { ev ->
            when (ev) {
                is PreviewEvent.Status -> _ui.update { it.copy(previewStatus = ev.text) }
                PreviewEvent.Running -> _ui.update { it.copy(previewStatus = "پیش‌نمایش در حال اجراست", previewRunning = true) }
                is PreviewEvent.Error -> {
                    _ui.update { it.copy(previewStatus = null, previewRunning = false, previewError = "${Labels.category(ev.category)}: ${ev.message}") }
                    recordManual(
                        TestKind.PREVIEW, id, TestStatus.FAILED, ev.category,
                        ev.message, "previewError"
                    )
                }
            }
        }
    }

    fun stopManual() {
        preview.stop()
        torchOff()
        _ui.update { it.copy(previewRunning = false, previewStatus = null) }
    }

    fun recordManual(kind: TestKind, id: String, status: TestStatus, cat: ErrorCategory?, msg: String, stage: String?, confirmed: Boolean = false) {
        val r = TestResult(
            kind, id, status, stage, null, cat, null, msg, mapOf("manual" to "true"), emptyList(),
            System.currentTimeMillis(), confirmed
        )
        _ui.update { it.copy(manualResults = it.manualResults + r) }
    }

    fun answerPreviewVisual(id: String, ok: Boolean) {
        if (ok) recordManual(TestKind.PREVIEW, id, TestStatus.PASSED, null, "کاربر تأیید کرد تصویر پیش‌نمایش درست نمایش داده می‌شود.", null, true)
        else recordManual(TestKind.PREVIEW, id, TestStatus.FAILED, ErrorCategory.USER_NEGATIVE, "کاربر گزارش کرد تصویر پیش‌نمایش سیاه یا خراب است.", "visual", true)
        _ui.update { it.copy(toast = "پاسخ شما ثبت شد (در گزارش بعدی لحاظ می‌شود).") }
    }

    fun setTorch(id: String, on: Boolean) {
        try {
            mgr.setTorchMode(id, on)
            torchId = if (on) id else null
            _ui.update { it.copy(torchOn = on) }
        } catch (e: CameraAccessException) {
            _ui.update { it.copy(toast = "چراغ‌قوه قابل‌آزمایش نبود: ${Labels.category(com.cameradiag.lab.core.ErrorClassifier.fromAccessReason(e.reason))}") }
        } catch (e: Exception) {
            _ui.update { it.copy(toast = "چراغ‌قوه خطا داد: ${e.javaClass.simpleName}") }
        }
    }

    fun torchOff() {
        val id = torchId ?: return
        try { mgr.setTorchMode(id, false) } catch (e: Exception) { }
        torchId = null
        _ui.update { it.copy(torchOn = false) }
    }

    fun answerTorchVisual(id: String, ok: Boolean) {
        if (ok) recordManual(TestKind.FLASH, id, TestStatus.PASSED, null, "کاربر تأیید کرد چراغ‌قوه روشن می‌شود.", null, true)
        else recordManual(TestKind.FLASH, id, TestStatus.FAILED, ErrorCategory.USER_NEGATIVE, "کاربر گزارش کرد چراغ‌قوه روشن نمی‌شود.", "visual", true)
        _ui.update { it.copy(toast = "پاسخ شما ثبت شد.") }
    }

    // ---------------------------------------------------------------- user report / settings
    fun saveUserReport(r: UserReport) {
        userStore.save(r)
        _ui.update { it.copy(userReport = r, toast = "گزارش دستی ذخیره شد.") }
    }

    fun saveSettings(s: AppSettings) {
        settingsStore.save(s)
        _ui.update { it.copy(settings = s) }
    }

    // ---------------------------------------------------------------- history / samples / share
    fun openReport(e: ReportEntry) {
        _ui.update { it.copy(viewingEntry = e, viewingText = reportStore.readText(e), screen = Screen.REPORT_VIEW) }
    }

    fun deleteReport(e: ReportEntry) {
        reportStore.delete(e)
        _ui.update { it.copy(history = reportStore.list(), screen = if (it.screen == Screen.REPORT_VIEW) Screen.HISTORY else it.screen, toast = "گزارش حذف شد.") }
    }

    fun deleteAllReports() {
        reportStore.deleteAll()
        _ui.update { it.copy(history = emptyList(), toast = "همه‌ی گزارش‌ها حذف شد.") }
    }

    fun refreshSamples() {
        _ui.update { it.copy(samples = sampleStore.list()) }
    }

    fun deleteSample(s: SampleFile) {
        sampleStore.delete(s.file)
        refreshSamples()
    }

    fun deleteAllSamples() {
        sampleStore.deleteAll()
        refreshSamples()
        _ui.update { it.copy(toast = "فایل‌های آزمایشی حذف شد.") }
    }

    fun requestShare(e: ReportEntry?) {
        _ui.update { it.copy(shareTarget = e) }
    }

    fun dismissShare() {
        _ui.update { it.copy(shareTarget = null) }
    }

    /** Opens the Android Sharesheet for the saved JSON or text report (nothing is sent until the user picks a target). */
    fun share(asJson: Boolean): Intent? {
        val e = _ui.value.shareTarget ?: return null
        val f = if (asJson) e.json else e.txt
        if (!f.exists()) {
            _ui.update { it.copy(shareTarget = null, toast = "فایل گزارش پیدا نشد.") }
            return null
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = if (asJson) "application/json" else "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        _ui.update { it.copy(shareTarget = null) }
        return Intent.createChooser(send, "اشتراک‌گذاری گزارش").apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    }

    override fun onCleared() {
        preview.stop()
        torchOff()
        runJob?.cancel()
        super.onCleared()
    }
}
