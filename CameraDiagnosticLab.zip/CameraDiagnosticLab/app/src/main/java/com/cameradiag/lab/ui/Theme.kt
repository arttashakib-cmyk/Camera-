package com.cameradiag.lab.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.cameradiag.lab.core.TestStatus

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF38BDF8),
    onPrimary = Color(0xFF04202C),
    secondary = Color(0xFF94A3B8),
    background = Color(0xFF0B1220),
    surface = Color(0xFF111A2E),
    surfaceVariant = Color(0xFF1A2540),
    onBackground = Color(0xFFE6EDF7),
    onSurface = Color(0xFFE6EDF7),
    onSurfaceVariant = Color(0xFFA9B8D3),
    error = Color(0xFFF87171),
    outline = Color(0xFF2B3A5C)
)

object StatusColors {
    val passed = Color(0xFF34D399)   // used only for a test that actually passed
    val failed = Color(0xFFF87171)
    val warning = Color(0xFFFBBF24)
    val neutral = Color(0xFF94A3B8)
    val info = Color(0xFF38BDF8)
    val inconclusive = Color(0xFFC4B5FD)

    fun of(s: TestStatus): Color = when (s) {
        TestStatus.PASSED -> passed
        TestStatus.FAILED -> failed
        TestStatus.WARNING -> warning
        TestStatus.NOT_TESTED -> neutral
        TestStatus.UNSUPPORTED -> neutral
        TestStatus.INCONCLUSIVE -> inconclusive
    }

    fun symbol(s: TestStatus): String = when (s) {
        TestStatus.PASSED -> "✓"
        TestStatus.FAILED -> "✕"
        TestStatus.WARNING -> "!"
        TestStatus.NOT_TESTED -> "○"
        TestStatus.UNSUPPORTED -> "–"
        TestStatus.INCONCLUSIVE -> "؟"
    }
}

@Composable
fun DiagTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = DarkScheme, content = content)
    }
}
